import {
  AddRounded,
  ArrowBackRounded,
  AttachFileRounded,
  AutoStoriesRounded,
  CheckCircleRounded,
  CloseRounded,
  CloudUploadRounded,
  ContentCopyRounded,
  DeleteOutlineRounded,
  EditNoteRounded,
  LinkRounded,
  MenuBookRounded,
  SaveRounded,
  SearchRounded,
  SendRounded,
  WarningAmberRounded,
} from "@mui/icons-material";
import {
  Alert,
  Box,
  Button,
  Checkbox,
  Chip,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  FormControlLabel,
  Grid,
  IconButton,
  InputAdornment,
  MenuItem,
  Paper,
  Stack,
  TextField,
  Tooltip,
  Typography,
} from "@mui/material";
import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { useAuthUser } from "react-auth-kit";
import {
  useLocation,
  useNavigate,
  useParams,
  useSearchParams,
} from "react-router-dom";
import { toast } from "react-toastify";

import Container from "@/components/Container/Container";
import PreparationDocumentView from "./PreparationDocumentView";
import { api } from "@/APIs/Axios";
import Loading from "@/components/Loading";
import usePermissions from "@/utils/hooks/usePermissions";
import {
  addPreparation,
  addPreparationFiles,
  addPreparationResource,
  deletePreparationResource,
  editPreparation,
  fetchPreparationReferenceLists,
  fetchPreparations,
  fetchSinglePreparation,
  reviewPreparation,
  submitPreparation,
} from "@/APIs/school/preparation";
import {
  fetchLectures,
  fetchSingleLecture,
} from "@/APIs/school/lectures";
import { fetchSingleSubjectOffering } from "@/APIs/school/subjectOfferings";
import {
  fetchCurriculumLessons,
  fetchCurriculumUnits,
} from "@/APIs/school/curriculum";
import {
  addLibraryResource,
  fetchLibraries,
} from "@/APIs/school/library";
import {
  fetchExams,
  fetchTeacherExams,
} from "@/APIs/school/exams";
import {
  fetchProjects,
  fetchTeacherProjects,
} from "@/APIs/school/projects";

const DRAFT_CACHE_TTL_MS = 2 * 60 * 60 * 1000;

const getDraftCacheKey = (lectureId) => {
  const id = normalizeId(lectureId);
  return id ? `nasaq:structured-preparation:${id}` : "";
};

const readDraftCache = (lectureId) => {
  if (typeof window === "undefined") return null;
  const key = getDraftCacheKey(lectureId);
  if (!key) return null;

  try {
    const parsed = JSON.parse(window.sessionStorage.getItem(key) || "null");
    if (!parsed?.form || !parsed?.updatedAt) return null;
    if (Date.now() - Number(parsed.updatedAt) > DRAFT_CACHE_TTL_MS) {
      window.sessionStorage.removeItem(key);
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
};

const writeDraftCache = (lectureId, form) => {
  if (typeof window === "undefined") return;
  const key = getDraftCacheKey(lectureId);
  if (!key) return;

  try {
    window.sessionStorage.setItem(
      key,
      JSON.stringify({
        updatedAt: Date.now(),
        form: { ...form, lecture: normalizeId(lectureId) },
      })
    );
  } catch {
    // sessionStorage may be unavailable in hardened/private browser modes.
  }
};

const clearDraftCache = (lectureId) => {
  if (typeof window === "undefined") return;
  const key = getDraftCacheKey(lectureId);
  if (!key) return;
  try {
    window.sessionStorage.removeItem(key);
  } catch {
    // Ignore storage cleanup failures.
  }
};
const MAX_ATTACHMENT_SIZE = 20 * 1024 * 1024;

const EMPTY_FORM = {
  lecture: "",
  unitId: "",
  lessonId: "",
  lessonTitle: "",
  warmup: "",
  vocabulary: "",
  objectives: [""],
  digitalContentIds: [],
  teachingStrategies: [],
  otherTeachingStrategy: "",
  educationalAids: [],
  otherEducationalAid: "",
  thinkingSkills: "",
  lessonClosing: "",
  enrichments: [],
  homeworks: [],
  exams: [],
  activities: [],
  teacherInstructions: "",
};

const STATUS_META = {
  draft: { label: "مسودة", tone: "warning" },
  pending: { label: "بانتظار المراجعة", tone: "info" },
  approved: { label: "معتمد", tone: "success" },
  needs_revision: { label: "يحتاج تعديل", tone: "error" },
};

const SCHOOL_ADMIN_ROLES = [
  "OWNER",
  "SUPERVISOR",
  "MANAGER",
  "ADMIN",
  "SUPER_ADMIN",
];

const ASSIGNMENT_GROUPS = [
  { key: "enrichments", label: "إثراءات المعلم", singular: "إثراء" },
  { key: "homeworks", label: "واجبات", singular: "واجب" },
  { key: "exams", label: "اختبارات", singular: "اختبار" },
  { key: "activities", label: "أنشطة", singular: "نشاط" },
];

const normalizeId = (value) => {
  if (value && typeof value === "object") {
    return String(value._id || value.id || "").trim();
  }
  return String(value || "").trim();
};

const normalizeRole = (value) =>
  String(value || "").trim().toUpperCase();

const unwrap = (value) => {
  let current = value;
  for (let index = 0; index < 5; index += 1) {
    if (
      !current ||
      Array.isArray(current) ||
      typeof current !== "object" ||
      !("data" in current)
    ) {
      break;
    }
    current = current.data;
  }
  return current;
};

const extractList = (value, preferredKeys = []) => {
  const payload = unwrap(value);
  if (Array.isArray(payload)) return payload;
  if (!payload || typeof payload !== "object") return [];

  const keys = [
    ...preferredKeys,
    "docs",
    "items",
    "results",
    "records",
    "data",
  ];

  for (const key of keys) {
    if (Array.isArray(payload?.[key])) return payload[key];
  }

  return Object.values(payload).find(Array.isArray) || [];
};

const extractEntity = (value) => {
  const payload = unwrap(value);
  if (!payload || Array.isArray(payload) || typeof payload !== "object") {
    return {};
  }
  return payload.preparation || payload.lecture || payload.item || payload;
};

const extractLectureDetail = (response) => {
  const candidates = [
    response?.data?.data,
    response?.data,
    response?.lecture,
    response,
  ];

  for (const candidate of candidates) {
    if (
      candidate &&
      !Array.isArray(candidate) &&
      typeof candidate === "object" &&
      (candidate?._id || candidate?.id) &&
      (candidate?.subjectOfferingId || candidate?.subjectOffering)
    ) {
      return candidate;
    }
  }

  const fallback = extractEntity(response);
  return fallback && typeof fallback === "object" ? fallback : {};
};

const extractSubjectOfferingDetail = (response) => {
  const candidates = [
    response?.data?.data,
    response?.data,
    response?.subjectOffering,
    response?.item,
    response,
  ];

  for (const candidate of candidates) {
    if (
      candidate &&
      !Array.isArray(candidate) &&
      typeof candidate === "object" &&
      (candidate?._id || candidate?.id) &&
      (candidate?.subjectId || candidate?.subject)
    ) {
      return candidate;
    }
  }

  const fallback = extractEntity(response);
  return fallback && typeof fallback === "object" ? fallback : {};
};

const getName = (value, fallback = "") => {
  if (value && typeof value === "object") {
    return String(
      value.name ||
        value.title ||
        value.label ||
        value.subjectName ||
        value.lessonTitle ||
        fallback
    ).trim();
  }
  return String(value || fallback).trim();
};

const getAttachmentLabel = (file, index = 0) => {
  if (typeof file === "string") {
    const name = file.split("/").filter(Boolean).pop() || "";
    try {
      return decodeURIComponent(name) || `مرفق ${index + 1}`;
    } catch {
      return name || `مرفق ${index + 1}`;
    }
  }

  return String(
    file?.originalName ||
      file?.name ||
      file?.filename ||
      file?.storedName ||
      file?.path?.split?.("/")?.pop?.() ||
      `مرفق ${index + 1}`
  );
};

const getCurrentUser = (authUser) => {
  const auth = typeof authUser === "function" ? authUser() : authUser;
  return auth?.user || auth || {};
};

const getLectureOffering = (lecture) =>
  (lecture?.subjectOfferingId && typeof lecture.subjectOfferingId === "object"
    ? lecture.subjectOfferingId
    : null) ||
  (lecture?.subjectOffering && typeof lecture.subjectOffering === "object"
    ? lecture.subjectOffering
    : null) ||
  {};

const getLectureSubject = (lecture) => {
  const offering = getLectureOffering(lecture);

  const subjectCandidates = [
    lecture?.subjectId,
    lecture?.subject,
    offering?.subjectId,
    offering?.subject,
  ];
  const entity =
    subjectCandidates.find(
      (item) => item && typeof item === "object" && !Array.isArray(item)
    ) || {};
  const id = subjectCandidates.map(normalizeId).find(Boolean) || "";

  return {
    id,
    name:
      getName(entity) ||
      String(
        lecture?.subjectName ||
          offering?.subjectName ||
          offering?.subject?.name ||
          offering?.subjectId?.name ||
          ""
      ).trim() ||
      "المادة",
    offeringId: normalizeId(
      lecture?.subjectOfferingId || lecture?.subjectOffering
    ),
  };
};

const getLectureGrade = (lecture) => {
  const offering = getLectureOffering(lecture);
  const classroom =
    (lecture?.classId && typeof lecture.classId === "object"
      ? lecture.classId
      : null) ||
    (lecture?.class && typeof lecture.class === "object" ? lecture.class : null) ||
    {};
  const candidates = [
    offering?.gradeLevelId,
    offering?.gradeLevel,
    classroom?.gradeLevelId,
    classroom?.gradeLevel,
    lecture?.gradeLevelId,
    lecture?.gradeLevel,
  ];
  const entity =
    candidates.find(
      (item) => item && typeof item === "object" && !Array.isArray(item)
    ) || {};

  return {
    id: candidates.map(normalizeId).find(Boolean) || "",
    name:
      getName(entity) ||
      String(
        offering?.gradeLevelName ||
          offering?.gradeName ||
          classroom?.gradeName ||
          lecture?.gradeName ||
          ""
      ).trim() ||
      "الصف الدراسي",
  };
};

const resolveLectureCurriculumContext = async (lecture) => {
  if (!lecture || typeof lecture !== "object") {
    return {
      lecture: lecture || null,
      context: {
        subjectId: "",
        subjectName: "المادة",
        subjectOfferingId: "",
        gradeLevelId: "",
        gradeName: "الصف الدراسي",
      },
    };
  }

  const rawOffering = lecture?.subjectOfferingId || lecture?.subjectOffering;
  const offeringId = normalizeId(rawOffering);
  let offering =
    rawOffering && typeof rawOffering === "object" && !Array.isArray(rawOffering)
      ? rawOffering
      : {};

  const offeringHasSubjectAndGrade = (value) =>
    Boolean(
      normalizeId(value?.subjectId || value?.subject) &&
        normalizeId(value?.gradeLevelId || value?.gradeLevel)
    );

  // The lecture endpoint normally returns the offering populated. Some list/detail
  // variants only return its id, so resolve the offering explicitly in that case.
  if (offeringId && !offeringHasSubjectAndGrade(offering)) {
    const response = await fetchSingleSubjectOffering(offeringId);
    if (response?.status) {
      const resolvedOffering = extractEntity(response);
      if (resolvedOffering && typeof resolvedOffering === "object") {
        offering = {
          ...offering,
          ...resolvedOffering,
        };
      }
    }
  }

  const subjectNode = offering?.subjectId || offering?.subject || null;
  const gradeNode = offering?.gradeLevelId || offering?.gradeLevel || null;

  const subjectId = normalizeId(subjectNode);
  const gradeLevelId = normalizeId(gradeNode);

  const normalizedOffering = {
    ...offering,
    ...(offeringId ? { _id: offering?._id || offeringId } : {}),
  };

  const normalizedLecture = {
    ...lecture,
    subjectOfferingId: normalizedOffering,
    subjectOffering: normalizedOffering,
  };

  return {
    lecture: normalizedLecture,
    context: {
      subjectId,
      subjectName:
        getName(subjectNode) ||
        String(
          subjectNode?.subjectName ||
            offering?.subjectName ||
            lecture?.subjectName ||
            ""
        ).trim() ||
        "المادة",
      subjectOfferingId: offeringId || normalizeId(normalizedOffering),
      gradeLevelId,
      gradeName:
        getName(gradeNode) ||
        String(
          gradeNode?.gradeName ||
            offering?.gradeLevelName ||
            offering?.gradeName ||
            lecture?.gradeName ||
            ""
        ).trim() ||
        "الصف الدراسي",
    },
  };
};

const hydrateLectureCurriculumContext = async (lecture) =>
  (await resolveLectureCurriculumContext(lecture)).lecture;

const getLectureCurriculumContext = (lecture) => {
  const subject = getLectureSubject(lecture || {});
  const grade = getLectureGrade(lecture || {});

  return {
    subjectId: subject.id,
    subjectName: subject.name,
    subjectOfferingId: subject.offeringId,
    gradeLevelId: grade.id,
    gradeName: grade.name,
  };
};

const getLectureClassId = (lecture) =>
  normalizeId(
    lecture?.classId ||
      lecture?.class
  );

const getLectureLabel = (lecture) => {
  const subject = getLectureSubject(lecture);
  const classroom =
    (lecture?.classId && typeof lecture.classId === "object"
      ? lecture.classId
      : null) ||
    (lecture?.class && typeof lecture.class === "object" ? lecture.class : null) ||
    {};
  const className =
    getName(classroom) || classroom?.roomNumber || lecture?.className || "";
  const slot = lecture?.slot || lecture?.period || "";
  const day = lecture?.dayOfWeek || lecture?.day || "";

  return [subject.name, className, day, slot ? `الحصة ${slot}` : ""]
    .filter(Boolean)
    .join(" — ");
};

const normalizeObjectiveRows = (value) => {
  const source = Array.isArray(value) ? value : [];
  const rows = source
    .map((item) =>
      typeof item === "string"
        ? item
        : item?.text || item?.title || item?.name || ""
    )
    .map((item) => String(item || ""));
  return rows.length ? rows : [""];
};

const normalizeIds = (value) =>
  (Array.isArray(value) ? value : [])
    .map((item) => normalizeId(item?.libraryItemId || item?.itemId || item))
    .filter(Boolean);

const normalizeChoiceArray = (value) =>
  (Array.isArray(value) ? value : [])
    .map((item) =>
      typeof item === "string"
        ? item
        : item?.value || item?.id || item?.name || item?.label || ""
    )
    .map((item) => String(item || "").trim())
    .filter(Boolean);

const normalizeAssignmentItems = (value) =>
  (Array.isArray(value) ? value : []).map((item, index) => {
    if (typeof item === "string") {
      return { id: item, resourceId: item, title: item };
    }
    return {
      ...item,
      id:
        normalizeId(item) ||
        String(item?.key || `local-${index}`),
      resourceId:
        normalizeId(
          item?._id ||
            item?.resourceId
        ) || "",
      examId:
        normalizeId(item?.examId) || "",
      projectId:
        normalizeId(item?.projectId) || "",
      title:
        getName(item) ||
        item?.examTitle ||
        item?.lessonTitle ||
        `عنصر ${index + 1}`,
      startDate:
        String(
          item?.startAt ||
            item?.startDate ||
            item?.from ||
            ""
        ).slice(0, 10),
      endDate:
        String(
          item?.dueAt ||
            item?.endDate ||
            item?.to ||
            ""
        ).slice(0, 10),
      description:
        String(item?.description || ""),
      link:
        String(item?.link || ""),
      totalGrade:
        item?.totalGrade ?? "",
    };
  });

const RESOURCE_GROUP_BY_TYPE = {
  enrichment: "enrichments",
  homework: "homeworks",
  quiz: "exams",
  activity: "activities",
};

const RESOURCE_TYPE_BY_GROUP = {
  enrichments: "enrichment",
  homeworks: "homework",
  exams: "quiz",
  activities: "activity",
};

const groupResources = (resources = []) => {
  const grouped = {
    enrichments: [],
    homeworks: [],
    exams: [],
    activities: [],
  };

  (Array.isArray(resources) ? resources : []).forEach(
    (resource) => {
      const group =
        RESOURCE_GROUP_BY_TYPE[
          String(resource?.type || "")
            .trim()
            .toLowerCase()
        ];

      if (!group) return;

      grouped[group].push(
        normalizeAssignmentItems(
          [resource]
        )[0]
      );
    }
  );

  return grouped;
};

const getStatus = (preparation) => {
  const status = String(
    preparation?.status || preparation?.reviewStatus || "draft"
  )
    .trim()
    .toLowerCase();

  if (status === "pending_review" || status === "submitted") return "pending";
  return STATUS_META[status] ? status : "draft";
};

const snapshot = (form) =>
  JSON.stringify({
    lecture: normalizeId(form.lecture),
    ...makePayload(form),
  });

const assignmentCount = (form) =>
  ASSIGNMENT_GROUPS.reduce(
    (total, group) => total + (form[group.key]?.length || 0),
    0
  );

const isOtherChoice = (item) => {
  const value = String(item?.value || item?.id || item?.name || item?.label || "")
    .trim()
    .toLowerCase();
  return value === "other" || value === "أخرى" || value.includes("other");
};

const normalizeReferenceChoices = (value) =>
  (Array.isArray(value) ? value : []).map((item, index) => {
    if (typeof item === "string") {
      return { id: item, value: item, label: item };
    }
    const id = String(item?.value || item?.id || item?._id || index);
    return {
      ...item,
      id,
      value: String(item?.value || item?.id || item?._id || item?.name || id),
      label: getName(item, id),
    };
  });

const getReferenceLists = (response) => {
  const data = extractEntity(response);
  const strategies =
    data?.teachingStrategies ||
    data?.strategies ||
    data?.teaching_strategies ||
    data?.methods ||
    [];
  const aids =
    data?.educationalAids ||
    data?.teachingAids ||
    data?.aids ||
    data?.educational_aids ||
    [];

  return {
    strategies: normalizeReferenceChoices(strategies),
    aids: normalizeReferenceChoices(aids),
  };
};

const getStructuredForm = (preparation = {}) => {
  const lessonRef =
    preparation?.lessonId ||
    preparation?.lesson ||
    null;
  const resources =
    groupResources(
      preparation?.resources
    );

  return {
    lecture:
      normalizeId(
        preparation?.lecture ||
          preparation?.lectureId
      ),
    unitId:
      normalizeId(
        preparation?.unitId ||
          preparation?.unit ||
          lessonRef?.unitId ||
          lessonRef?.unit
      ),
    lessonId:
      normalizeId(lessonRef),
    lessonTitle:
      String(
        preparation?.lessonTitle ||
          getName(lessonRef) ||
          ""
      ),
    warmup:
      String(
        preparation?.warmUp ||
          preparation?.warmup ||
          preparation?.introduction ||
          ""
      ),
    vocabulary:
      String(
        preparation?.vocabulary ||
          preparation?.lessonVocabulary ||
          ""
      ),
    objectives:
      normalizeObjectiveRows(
        preparation?.objectives
      ),
    digitalContentIds:
      normalizeIds(
        preparation?.digitalContentIds ||
          preparation?.digitalContents ||
          preparation?.libraryItems
      ),
    teachingStrategies:
      normalizeChoiceArray(
        preparation?.teachingStrategies
      ),
    otherTeachingStrategy:
      String(
        preparation?.strategiesOther ||
          preparation?.otherTeachingStrategy ||
          ""
      ),
    educationalAids:
      normalizeChoiceArray(
        preparation?.teachingAids ||
          preparation?.educationalAids
      ),
    otherEducationalAid: "",
    thinkingSkills:
      String(
        preparation?.thinkingSkills ||
          ""
      ),
    lessonClosing:
      String(
        preparation?.closure ||
          preparation?.lessonClosing ||
          preparation?.closing ||
          ""
      ),
    enrichments:
      resources.enrichments.length
        ? resources.enrichments
        : normalizeAssignmentItems(
            preparation?.enrichments
          ),
    homeworks:
      resources.homeworks.length
        ? resources.homeworks
        : normalizeAssignmentItems(
            preparation?.homeworks ||
              preparation?.assignments
          ),
    exams:
      resources.exams.length
        ? resources.exams
        : normalizeAssignmentItems(
            preparation?.exams
          ),
    activities:
      resources.activities.length
        ? resources.activities
        : normalizeAssignmentItems(
            preparation?.activities
          ),
    teacherInstructions:
      String(
        preparation?.teacherInstructions ||
          ""
      ),
  };
};

const makePayload = (form) => {
  const teachingAids = [
    ...form.educationalAids,
  ];

  if (
    form.educationalAids.some(
      (value) =>
        String(value)
          .trim()
          .toLowerCase() === "other" ||
        String(value).trim() === "أخرى"
    ) &&
    String(
      form.otherEducationalAid || ""
    ).trim()
  ) {
    teachingAids.push(
      String(
        form.otherEducationalAid
      ).trim()
    );
  }

  const payload = {
    warmUp:
      String(form.warmup || ""),
    vocabulary:
      String(form.vocabulary || ""),
    objectives:
      form.objectives
        .map((item) =>
          String(item || "").trim()
        )
        .filter(Boolean),
    digitalContentIds:
      form.digitalContentIds
        .map(normalizeId)
        .filter(Boolean),
    teachingStrategies:
      form.teachingStrategies,
    strategiesOther:
      String(
        form.otherTeachingStrategy ||
          ""
      ),
    teachingAids,
    thinkingSkills:
      String(
        form.thinkingSkills || ""
      ),
    closure:
      String(
        form.lessonClosing || ""
      ),
    teacherInstructions:
      String(
        form.teacherInstructions ||
          ""
      ),
  };

  const lessonId =
    normalizeId(form.lessonId);

  if (lessonId) {
    payload.lessonId =
      lessonId;
  }

  return payload;
};

const makeChangedPayload = (form, previousSnapshot = "") => {
  const current = makePayload(form);

  let previous = {};
  try {
    const parsed = JSON.parse(previousSnapshot || "{}");
    previous = parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    previous = {};
  }

  const changed = {};

  Object.entries(current).forEach(([key, value]) => {
    const before = previous?.[key];
    if (JSON.stringify(value) !== JSON.stringify(before)) {
      changed[key] = value;
    }
  });

  return changed;
};

const dateOnlyToIso = (
  value,
  endOfDay = false
) => {
  const date = String(
    value || ""
  ).trim();

  if (!date) return "";

  const suffix = endOfDay
    ? "T23:59:59.999Z"
    : "T00:00:00.000Z";

  return `${date}${suffix}`;
};

const StudentBadge = () => (
  <Chip
    size="small"
    label="تظهر في حساب الطالب"
    sx={{
      height: 22,
      bgcolor: "rgba(36,74,112,.07)",
      color: "var(--color-muted)",
      fontSize: 9,
      fontWeight: 800,
    }}
  />
);

const FieldLabel = ({ children, studentVisible = false, required = false }) => (
  <Stack direction="row" alignItems="center" gap={0.7} flexWrap="wrap" mb={0.65}>
    <Typography sx={{ color: "var(--color-navy-deep)", fontWeight: 900, fontSize: 12.5 }}>
      {children}{required ? " *" : ""}
    </Typography>
    {studentVisible && <StudentBadge />}
  </Stack>
);

const PreparationPageWrapper = ({ teacherPortal, children }) =>
  teacherPortal ? (
    <Box
      sx={{
        minHeight: "100dvh",
        bgcolor: "#fff",
        px: { xs: 1, md: 1.5 },
        py: 1.2,
      }}
    >
      <Box sx={{ maxWidth: 1380, mx: "auto" }}>{children}</Box>
    </Box>
  ) : (
    <Container>{children}</Container>
  );

const SectionCard = ({ title, subtitle, icon, children, id }) => (
  <Paper
    id={id}
    elevation={0}
    sx={{
      p: { xs: 1.25, md: 1.65 },
      border: "1px solid rgba(36,74,112,.10)",
      borderRadius: "20px",
      bgcolor: "#fff",
      boxShadow: "0 12px 30px rgba(18,47,77,.05)",
      scrollMarginTop: 145,
      overflow: "hidden",
    }}
  >
    <Stack
      direction={{ xs: "column", sm: "row" }}
      alignItems={{ xs: "flex-start", sm: "center" }}
      justifyContent="space-between"
      gap={0.8}
      mb={1.35}
      sx={{ pb: 1, borderBottom: "1px solid rgba(36,74,112,.07)" }}
    >
      <Stack direction="row" alignItems="center" gap={1}>
        <Box
          sx={{
            width: 42,
            height: 42,
            borderRadius: "13px",
            bgcolor: "linear-gradient(135deg, var(--color-gold-soft), #fff)",
            background: "linear-gradient(135deg, var(--color-gold-soft), #fff)",
            border: "1px solid rgba(200,146,36,.16)",
            color: "var(--color-gold-dark)",
            display: "grid",
            placeItems: "center",
            flexShrink: 0,
          }}
        >
          {icon}
        </Box>
        <Box>
          <Typography sx={{ color: "var(--color-navy-deep)", fontWeight: 900, fontSize: 15.5 }}>
            {title}
          </Typography>
          {subtitle ? (
            <Typography sx={{ color: "var(--color-muted)", fontSize: 10.5, mt: 0.18, lineHeight: 1.7 }}>
              {subtitle}
            </Typography>
          ) : null}
        </Box>
      </Stack>
    </Stack>
    {children}
  </Paper>
);

const WizardSteps = ({ step, onStep, stepTwoEnabled }) => (
  <Paper
    elevation={0}
    sx={{
      position: "sticky",
      top: 8,
      zIndex: 20,
      p: 1,
      border: "1px solid rgba(36,74,112,.1)",
      borderRadius: "16px",
      bgcolor: "rgba(255,255,255,.95)",
      backdropFilter: "blur(12px)",
      boxShadow: "0 8px 24px rgba(18,47,77,.08)",
    }}
  >
    <Stack direction="row" alignItems="center" justifyContent="center" spacing={0}>
      {[1, 2].map((number, index) => {
        const active = step === number;
        const enabled = number === 1 || stepTwoEnabled;
        return (
          <Stack
            key={number}
            direction="row"
            alignItems="center"
            sx={{ flex: index === 0 ? 1 : "unset", minWidth: 0 }}
          >
            <Button
              type="button"
              disabled={!enabled}
              onClick={() => onStep(number)}
              sx={{
                minWidth: 0,
                px: 0.8,
                color: active ? "var(--color-navy-deep)" : "var(--color-muted)",
                textTransform: "none",
              }}
            >
              <Stack alignItems="center" gap={0.3}>
                <Box
                  sx={{
                    width: 30,
                    height: 30,
                    borderRadius: "50%",
                    display: "grid",
                    placeItems: "center",
                    bgcolor: active ? "var(--color-navy)" : enabled ? "var(--color-gold-soft)" : "#f0f1f3",
                    color: active ? "#fff" : enabled ? "var(--color-gold-dark)" : "#aaa",
                    fontWeight: 900,
                    fontSize: 12,
                  }}
                >
                  {number}
                </Box>
                <Typography sx={{ fontSize: 10.5, fontWeight: 900, whiteSpace: "nowrap" }}>
                  {number === 1 ? "المعلومات الأساسية" : "إعداد الدرس"}
                </Typography>
              </Stack>
            </Button>
            {index === 0 && (
              <Box
                sx={{
                  flex: 1,
                  height: 3,
                  mx: { xs: 0.4, sm: 1 },
                  borderRadius: 99,
                  bgcolor: stepTwoEnabled ? "var(--color-gold)" : "rgba(36,74,112,.12)",
                }}
              />
            )}
          </Stack>
        );
      })}
    </Stack>
  </Paper>
);

const PreparationProgress = ({ form, step, assignmentTotal = 0 }) => {
  const objectivesCount = (form.objectives || []).filter((item) => String(item || "").trim()).length;
  const digitalCount = (form.digitalContentIds || []).length;
  const checks = [
    { label: "الدرس", done: Boolean(form.lessonId) },
    { label: "الأهداف", done: objectivesCount > 0 },
    { label: "المحتوى الرقمي", done: digitalCount > 0 },
    { label: "تكليف واحد على الأقل", done: assignmentTotal > 0 },
  ];
  const completed = checks.filter((item) => item.done).length;
  const percent = Math.round((completed / checks.length) * 100);

  return (
    <Paper
      elevation={0}
      sx={{
        mt: 1,
        p: 1.05,
        borderRadius: "16px",
        border: "1px solid rgba(36,74,112,.09)",
        bgcolor: "#fbfcfe",
      }}
    >
      <Stack direction={{ xs: "column", md: "row" }} alignItems={{ xs: "stretch", md: "center" }} justifyContent="space-between" gap={1}>
        <Box sx={{ minWidth: 180 }}>
          <Stack direction="row" alignItems="center" justifyContent="space-between" gap={1} mb={0.45}>
            <Typography sx={{ color: "var(--color-navy-deep)", fontSize: 11.5, fontWeight: 900 }}>
              جاهزية التحضير للإرسال
            </Typography>
            <Typography sx={{ color: percent === 100 ? "#18865d" : "var(--color-gold-dark)", fontSize: 11, fontWeight: 900 }}>
              {percent}%
            </Typography>
          </Stack>
          <Box sx={{ height: 6, borderRadius: 99, bgcolor: "rgba(36,74,112,.09)", overflow: "hidden" }}>
            <Box sx={{ width: `${percent}%`, height: "100%", borderRadius: 99, bgcolor: percent === 100 ? "#18865d" : "var(--color-gold)" }} />
          </Box>
        </Box>
        <Stack direction="row" flexWrap="wrap" gap={0.55} justifyContent={{ xs: "flex-start", md: "flex-end" }}>
          {checks.map((item) => (
            <Chip
              key={item.label}
              size="small"
              icon={item.done ? <CheckCircleRounded /> : undefined}
              label={item.label}
              sx={{
                height: 27,
                fontSize: 9.5,
                fontWeight: 900,
                bgcolor: item.done ? "#eaf7f1" : "#fff7e5",
                color: item.done ? "#18865d" : "#9a6815",
                border: `1px solid ${item.done ? "rgba(24,134,93,.16)" : "rgba(200,146,36,.18)"}`,
                "& .MuiChip-icon": { color: "inherit" },
              }}
            />
          ))}
        </Stack>
      </Stack>
      <Typography sx={{ mt: 0.55, color: "var(--color-muted)", fontSize: 9.5 }}>
        {step === 1
          ? "أكمل بيانات الدرس ثم انتقل إلى إعداد الدرس. الحفظ التلقائي يعمل أثناء الكتابة."
          : percent === 100
            ? "التحضير مستوفٍ المتطلبات الأساسية ويمكن إرساله للمراجعة."
            : "أكمل العناصر الناقصة قبل إرسال التحضير للمراجعة."}
      </Typography>
    </Paper>
  );
};

const ChoiceChecklist = ({ options, values, onChange, disabled, otherValue, onOtherChange }) => {
  const selected = new Set(values);
  const hasOther = options.some((option) => isOtherChoice(option) && selected.has(option.value));

  return (
    <Stack spacing={0.45}>
      <Grid container spacing={0.4}>
        {options.map((option) => (
          <Grid item xs={12} sm={6} key={option.id}>
            <FormControlLabel
              disabled={disabled}
              control={
                <Checkbox
                  size="small"
                  checked={selected.has(option.value)}
                  onChange={(event) => {
                    const next = new Set(values);
                    if (event.target.checked) next.add(option.value);
                    else next.delete(option.value);
                    onChange(Array.from(next));
                  }}
                />
              }
              label={option.label}
              sx={{
                m: 0,
                width: "100%",
                minHeight: 40,
                px: 0.7,
                borderRadius: "11px",
                border: selected.has(option.value)
                  ? "1px solid rgba(24,134,93,.24)"
                  : "1px solid rgba(36,74,112,.08)",
                bgcolor: selected.has(option.value) ? "#f1faf6" : "#fbfcfe",
                transition: "all .18s ease",
                "&:hover": { bgcolor: disabled ? undefined : "#f7fafc" },
                "& .MuiFormControlLabel-label": { fontSize: 11.5, fontWeight: 800, color: "var(--color-navy-deep)" },
              }}
            />
          </Grid>
        ))}
      </Grid>
      {hasOther && (
        <TextField
          fullWidth
          size="small"
          disabled={disabled}
          value={otherValue}
          onChange={(event) => onOtherChange(event.target.value)}
          placeholder="اكتب الخيار الآخر"
          inputProps={{ maxLength: 300 }}
        />
      )}
    </Stack>
  );
};

const AssignmentCard = ({
  item,
  group,
  onRemove,
  onEdit,
  onAnswers,
  readOnly,
}) => (
  <Paper
    variant="outlined"
    sx={{
      p: 1.05,
      borderRadius: "14px",
      borderColor: "rgba(36,74,112,.10)",
      bgcolor: "#fff",
      boxShadow: "0 5px 16px rgba(18,47,77,.035)",
    }}
  >
    <Stack direction={{ xs: "column", sm: "row" }} alignItems={{ xs: "stretch", sm: "center" }} justifyContent="space-between" gap={1}>
      <Box sx={{ minWidth: 0 }}>
        <Typography noWrap sx={{ color: "var(--color-navy-deep)", fontWeight: 900, fontSize: 11.5 }}>
          {group.singular} — {item.title || "بدون عنوان"}
        </Typography>
        {(item.startDate || item.endDate) && (
          <Typography sx={{ color: "var(--color-muted)", fontSize: 9.5, mt: 0.3 }}>
            {item.startDate ? `البداية: ${item.startDate}` : ""}
            {item.startDate && item.endDate ? "   " : ""}
            {item.endDate ? `النهاية: ${item.endDate}` : ""}
          </Typography>
        )}
      </Box>
      <Stack direction="row" alignItems="center" gap={0.35} justifyContent="flex-end">
        {onAnswers && (
          <Button size="small" onClick={onAnswers} sx={{ minWidth: 0, px: 0.8, fontSize: 9.5, fontWeight: 900, textTransform: "none" }}>
            الإجابات
          </Button>
        )}
        {onEdit && !readOnly && (
          <Button size="small" onClick={onEdit} sx={{ minWidth: 0, px: 0.8, fontSize: 9.5, fontWeight: 900, textTransform: "none" }}>
            تعديل
          </Button>
        )}
        {!readOnly && (
          <Tooltip title="إزالة من التحضير">
            <IconButton size="small" onClick={onRemove} sx={{ color: "var(--color-danger)" }}>
              <DeleteOutlineRounded fontSize="small" />
            </IconButton>
          </Tooltip>
        )}
      </Stack>
    </Stack>
  </Paper>
);

const StructuredPreparationForm = ({ mode = "create" }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const params = useParams();
  const [searchParams] = useSearchParams();
  const authUser = useAuthUser();
  const currentUser = getCurrentUser(authUser);
  const role = normalizeRole(currentUser?.role);
  const preparationPermissions = usePermissions("preparation");
  const canReviewPreparation = usePermissions("preparation", "review");
  const teacherPortal = location.pathname.startsWith("/teacher/");
  const explicitId =
    mode === "create" ? "" : normalizeId(params?.id);
  const preselectedLectureId = String(searchParams.get("lectureId") || "").trim();
  const requestedReturnTo = String(searchParams.get("returnTo") || "").trim();
  const safeReturnTo =
    requestedReturnTo.startsWith("/teacher/") || requestedReturnTo.startsWith("/school/")
      ? requestedReturnTo
      : teacherPortal
        ? "/teacher/preparations"
        : "/school/preparation";

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [preparationId, setPreparationId] = useState(() =>
    mode === "create" ? "" : explicitId
  );
  const [preparationStatus, setPreparationStatus] = useState("draft");
  const [preparationRecord, setPreparationRecord] = useState(null);
  const [reviewNote, setReviewNote] = useState("");
  const [reviewDialog, setReviewDialog] = useState(false);
  const [reviewDraft, setReviewDraft] = useState("");
  const [reviewing, setReviewing] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [step, setStep] = useState(1);
  const [lectures, setLectures] = useState([]);
  const [lecture, setLecture] = useState(null);
  const [lectureContext, setLectureContext] = useState({
    subjectId: "",
    subjectName: "المادة",
    subjectOfferingId: "",
    gradeLevelId: "",
    gradeName: "الصف الدراسي",
  });
  const [units, setUnits] = useState([]);
  const [lessons, setLessons] = useState([]);
  const [curriculumLoading, setCurriculumLoading] = useState(false);
  const [curriculumMessage, setCurriculumMessage] = useState("");
  const [referenceLists, setReferenceLists] = useState({ strategies: [], aids: [] });
  const [libraryItems, setLibraryItems] = useState([]);
  const [librarySearch, setLibrarySearch] = useState("");
  const [libraryLoading, setLibraryLoading] = useState(false);
  const [libraryDialog, setLibraryDialog] = useState(false);
  const [libraryDraft, setLibraryDraft] = useState({ title: "", link: "", file: null });
  const [librarySaving, setLibrarySaving] = useState(false);
  const [assignmentDialog, setAssignmentDialog] = useState(null);
  const [assignmentEditIndex, setAssignmentEditIndex] = useState(null);
  const [assignmentDraft, setAssignmentDraft] = useState({
    title: "",
    description: "",
    startDate: "",
    endDate: "",
    totalGrade: "",
    link: "",
  });
  const [examOptions, setExamOptions] = useState([]);
  const [examLoading, setExamLoading] = useState(false);
  const [projectOptions, setProjectOptions] = useState([]);
  const [projectLoading, setProjectLoading] = useState(false);
  const [resourceSaving, setResourceSaving] = useState(false);
  const [attachment, setAttachment] = useState(null);
  const [existingFiles, setExistingFiles] = useState([]);
  const [validationErrors, setValidationErrors] = useState([]);
  const [suggestedObjectives, setSuggestedObjectives] = useState(false);
  const savedSnapshotRef = useRef(snapshot(EMPTY_FORM));
  const lastSaveRef = useRef(null);
  const dirtyRef = useRef(false);
  const objectivePrefillLessonRef = useRef("");
  const mountedRef = useRef(true);
  const createDraftPromiseRef = useRef(null);
  const savePromiseRef = useRef(null);
  const preparationIdRef = useRef("");
  const autosaveCreateBlockedRef = useRef(false);

  const subject = useMemo(
    () => ({
      id: lectureContext.subjectId,
      name: lectureContext.subjectName || "المادة",
      offeringId: lectureContext.subjectOfferingId,
    }),
    [lectureContext]
  );
  const grade = useMemo(
    () => ({
      id: lectureContext.gradeLevelId,
      name: lectureContext.gradeName || "الصف الدراسي",
    }),
    [lectureContext]
  );
  const currentSnapshot = useMemo(() => snapshot(form), [form]);
  const dirty = currentSnapshot !== savedSnapshotRef.current || Boolean(attachment);
  const readOnly =
    mode === "view" ||
    preparationStatus === "pending";
  const editable =
    mode !== "view" &&
    preparationStatus !== "pending";
  const canPickLecture = mode === "create" && !preselectedLectureId && !preparationId;
  const canReview =
    mode === "view" &&
    preparationStatus === "pending" &&
    canReviewPreparation;

  useEffect(() => {
    dirtyRef.current = dirty;
  }, [dirty]);

  useEffect(() => {
    preparationIdRef.current = normalizeId(preparationId);
  }, [preparationId]);

  const updateForm = useCallback((patch) => {
    setForm((current) => ({ ...current, ...patch }));
  }, []);

  useEffect(() => {
    if (mode !== "create") return undefined;
    const lectureId = normalizeId(form.lecture);
    if (!lectureId) return undefined;

    const timer = window.setTimeout(() => {
      writeDraftCache(lectureId, form);
    }, 120);

    return () => window.clearTimeout(timer);
  }, [form, mode]);

  const goBack = useCallback(() => {
    if (dirty && !window.confirm("لديك تغييرات لم يتم حفظها. هل تريد المغادرة؟")) {
      return;
    }
    navigate(safeReturnTo);
  }, [dirty, navigate, safeReturnTo]);

  const navigateAway = useCallback(
    (target) => {
      if (dirty && !window.confirm("لديك تغييرات لم يتم حفظها. هل تريد المغادرة؟")) {
        return;
      }
      navigate(target);
    },
    [dirty, navigate]
  );

  useEffect(() => {
    const beforeUnload = (event) => {
      if (!dirty) return;
      event.preventDefault();
      event.returnValue = "";
    };
    window.addEventListener("beforeunload", beforeUnload);
    return () => window.removeEventListener("beforeunload", beforeUnload);
  }, [dirty]);

  useEffect(() => () => {
    mountedRef.current = false;
  }, []);

  useEffect(() => {
    let active = true;

    const load = async () => {
      setLoading(true);
      try {
        const refsPromise = fetchPreparationReferenceLists();
        let initialPreparation = null;
        let lectureId = preselectedLectureId;
        let cachedDraft = !explicitId && lectureId
          ? readDraftCache(lectureId)
          : null;

        if (explicitId) {
          // اقرأ detail الخام مباشرة من Axios. صفحة العرض تعتمد على read model
          // الكامل (lesson/resources/digitalContent/review fields)، وبعض helpers
          // القديمة كانت تطبع envelope بشكل مختلف حسب النسخة.
          const prepHttpResponse = await api.get(`/preparation/${explicitId}`);
          const prepEnvelope = prepHttpResponse?.data || {};
          if (prepEnvelope?.status === false) {
            toast.error(prepEnvelope?.message || "تعذر تحميل التحضير");
            return;
          }
          initialPreparation =
            prepEnvelope?.data &&
            !Array.isArray(prepEnvelope.data) &&
            typeof prepEnvelope.data === "object"
              ? prepEnvelope.data
              : prepEnvelope;
          lectureId = normalizeId(initialPreparation?.lecture || initialPreparation?.lectureId);
        } else if (lectureId) {
          /*
           * /add can be revisited or remounted after the first draft POST.
           * Re-open the existing preparation for this exact lecture instead of
           * starting from EMPTY_FORM again. This is what keeps the chosen unit
           * and lesson visible after the first save.
           */
          const existingResponse = await fetchPreparations({
            lectureId,
            page: 1,
            limit: 20,
          });

          if (existingResponse?.status) {
            const matching = extractList(existingResponse, ["preparations"])
              .filter(
                (item) =>
                  normalizeId(item?.lecture || item?.lectureId) ===
                  normalizeId(lectureId)
              )
              .sort((a, b) => {
                const aTime = Date.parse(a?.updatedAt || a?.createdAt || 0) || 0;
                const bTime = Date.parse(b?.updatedAt || b?.createdAt || 0) || 0;
                return bTime - aTime;
              });

            const existingId = normalizeId(matching[0]);
            if (existingId) {
              const prepHttpResponse = await api.get(`/preparation/${existingId}`);
              const prepEnvelope = prepHttpResponse?.data || {};
              if (prepEnvelope?.status !== false) {
                initialPreparation =
                  prepEnvelope?.data &&
                  !Array.isArray(prepEnvelope.data) &&
                  typeof prepEnvelope.data === "object"
                    ? prepEnvelope.data
                    : prepEnvelope;
                lectureId = normalizeId(
                  initialPreparation?.lecture ||
                    initialPreparation?.lectureId ||
                    lectureId
                );
              }
            }
          }
        }

        let lectureRows = [];
        let initialLectureContext = null;
        if (lectureId) {
          const lectureResponse = await fetchSingleLecture(lectureId, { force: true });
          if (lectureResponse?.status) {
            // Resolve the curriculum context from the exact lecture detail
            // response once and keep that exact result. Do not recompute it
            // from a second state snapshot during initial render.
            const rawLecture = extractEntity(lectureResponse);
            const resolvedLecture = await resolveLectureCurriculumContext(rawLecture);
            lectureRows = [resolvedLecture.lecture].filter(Boolean);
            initialLectureContext = resolvedLecture.context;
          }
        } else {
          const filters = SCHOOL_ADMIN_ROLES.includes(role)
            ? {}
            : { teacherId: normalizeId(currentUser?.teacherId || currentUser) };
          const lectureResponse = await fetchLectures(filters, { force: true });
          if (lectureResponse?.status) {
            lectureRows = extractList(lectureResponse, ["lectures"]);
          }
        }

        const refsResponse = await refsPromise;
        if (!active) return;

        setReferenceLists(getReferenceLists(refsResponse));
        setLectures(lectureRows.filter((item) => normalizeId(item)));

        if (lectureId) {
          const selectedLecture =
            lectureRows.find((item) => normalizeId(item) === lectureId) ||
            lectureRows[0] ||
            null;
          setLecture(selectedLecture);
          if (selectedLecture && initialLectureContext) {
            setLectureContext(initialLectureContext);
          }
        }

        if (initialPreparation) {
          let normalized = getStructuredForm(initialPreparation);

          // If the add screen was remounted while a PATCH was still finishing,
          // the server detail may briefly lag behind what the teacher had on
          // screen. Restore only a newer session snapshot for editable drafts.
          const serverUpdatedAt =
            Date.parse(initialPreparation?.updatedAt || initialPreparation?.createdAt || 0) ||
            0;
          const cachedUpdatedAt = Number(cachedDraft?.updatedAt || 0);
          const status = getStatus(initialPreparation);
          if (
            cachedDraft?.form &&
            cachedUpdatedAt > serverUpdatedAt &&
            ["draft", "needs_revision"].includes(status)
          ) {
            normalized = {
              ...normalized,
              ...cachedDraft.form,
              lecture: lectureId || normalized.lecture,
            };
          }

          setForm(normalized);
          savedSnapshotRef.current = snapshot(normalized);
          objectivePrefillLessonRef.current =
            normalizeId(normalized.lessonId);
          const initialPreparationId = normalizeId(initialPreparation);
          preparationIdRef.current = initialPreparationId;
          setPreparationId(initialPreparationId);
          setPreparationStatus(getStatus(initialPreparation));
          setPreparationRecord(initialPreparation);
          setReviewNote(String(initialPreparation?.reviewNote || ""));
          setExistingFiles(
            extractList(
              { data: initialPreparation?.files || initialPreparation?.attachments || [] },
              ["files", "attachments"]
            )
          );
        } else {
          const cachedForm = cachedDraft?.form;
          const initial = cachedForm
            ? { ...EMPTY_FORM, ...cachedForm, lecture: lectureId || cachedForm.lecture || "" }
            : { ...EMPTY_FORM, lecture: lectureId || "" };
          setForm(initial);
          savedSnapshotRef.current = snapshot(initial);
        }
      } catch (error) {
        toast.error(error?.response?.data?.message || "تعذر فتح نموذج التحضير");
      } finally {
        if (active) setLoading(false);
      }
    };

    load();
    return () => {
      active = false;
    };
  }, [explicitId, preselectedLectureId, role]);

  useEffect(() => {
    const targetLectureId = normalizeId(form.lecture);
    let cancelled = false;

    if (!targetLectureId) {
      setLecture(null);
      setLectureContext({
        subjectId: "",
        subjectName: "المادة",
        subjectOfferingId: "",
        gradeLevelId: "",
        gradeName: "الصف الدراسي",
      });
      setUnits([]);
      setLessons([]);
      setCurriculumMessage("");
      return () => {
        cancelled = true;
      };
    }

    const run = async () => {
      setCurriculumLoading(true);
      setCurriculumMessage("");

      try {
        // Use the shared Axios instance directly here so we consume the exact
        // backend envelope visible in DevTools, independent of any lecture API
        // helper normalization/caching version.
        const lectureHttpResponse = await api.get(`/lectures/${targetLectureId}`);
        if (cancelled) return;

        const lectureEnvelope = lectureHttpResponse?.data || {};
        if (lectureEnvelope?.status === false) {
          setUnits([]);
          setLessons([]);
          setCurriculumMessage(
            lectureEnvelope?.message || "تعذر تحميل بيانات الحصة"
          );
          return;
        }

        const rawLecture =
          lectureEnvelope?.data && typeof lectureEnvelope.data === "object"
            ? lectureEnvelope.data
            : lectureEnvelope;

        let rawOffering =
          rawLecture?.subjectOfferingId || rawLecture?.subjectOffering || null;
        const offeringId = normalizeId(rawOffering);
        let offering =
          rawOffering &&
          typeof rawOffering === "object" &&
          !Array.isArray(rawOffering)
            ? rawOffering
            : {};

        const hasSubjectAndGrade = (value) =>
          Boolean(
            normalizeId(value?.subjectId || value?.subject) &&
              normalizeId(value?.gradeLevelId || value?.gradeLevel)
          );

        if (offeringId && !hasSubjectAndGrade(offering)) {
          const offeringHttpResponse = await api.get(
            `/subject-offerings/${offeringId}`
          );
          if (cancelled) return;

          const offeringEnvelope = offeringHttpResponse?.data || {};
          if (offeringEnvelope?.status !== false) {
            const offeringPayload =
              offeringEnvelope?.data && typeof offeringEnvelope.data === "object"
                ? offeringEnvelope.data
                : offeringEnvelope;
            if (offeringPayload && typeof offeringPayload === "object") {
              offering = { ...offering, ...offeringPayload };
              rawOffering = offering;
            }
          }
        }

        const subjectNode = offering?.subjectId || offering?.subject || null;
        const gradeNode = offering?.gradeLevelId || offering?.gradeLevel || null;
        const subjectId = normalizeId(subjectNode);
        const gradeLevelId = normalizeId(gradeNode);
        const subjectName =
          String(
            subjectNode?.subjectName ||
              subjectNode?.name ||
              offering?.subjectName ||
              ""
          ).trim() || "المادة";
        const gradeName =
          String(
            gradeNode?.name ||
              gradeNode?.gradeName ||
              offering?.gradeLevelName ||
              offering?.gradeName ||
              ""
          ).trim() || "الصف الدراسي";

        const normalizedOffering = {
          ...offering,
          ...(offeringId ? { _id: offering?._id || offeringId } : {}),
        };
        const nextLecture = {
          ...rawLecture,
          subjectOfferingId: normalizedOffering,
          subjectOffering: normalizedOffering,
        };

        // Update the visible subject/grade immediately from the exact backend
        // paths before any curriculum request.
        setLecture(nextLecture);
        setLectureContext({
          subjectId,
          subjectName,
          subjectOfferingId: offeringId || normalizeId(normalizedOffering),
          gradeLevelId,
          gradeName,
        });

        setLectures((current) => {
          const exists = current.some(
            (item) => normalizeId(item) === targetLectureId
          );
          if (exists) {
            return current.map((item) =>
              normalizeId(item) === targetLectureId ? nextLecture : item
            );
          }
          return nextLecture ? [nextLecture, ...current] : current;
        });

        if (!subjectId || !gradeLevelId) {
          setUnits([]);
          setLessons([]);
          setCurriculumMessage(
            "تعذر تحديد مادة أو صف الحصة — راجع إعداد عرض المادة"
          );
          return;
        }

        // Also call curriculum directly with the exact IDs read above so this
        // path cannot be blocked by a stale helper/cache response.
        const unitsHttpResponse = await api.get("/curriculum/units", {
          params: { subjectId, gradeLevelId },
        });
        if (cancelled) return;

        const unitsEnvelope = unitsHttpResponse?.data || {};
        if (unitsEnvelope?.status === false) {
          setUnits([]);
          setLessons([]);
          setCurriculumMessage(
            unitsEnvelope?.message || "تعذر تحميل وحدات المنهج"
          );
          return;
        }

        const unitsPayload =
          unitsEnvelope?.data !== undefined
            ? unitsEnvelope.data
            : unitsEnvelope;
        const rows = Array.isArray(unitsPayload)
          ? unitsPayload
          : Array.isArray(unitsPayload?.units)
            ? unitsPayload.units
            : [];

        setUnits(rows);
        setLessons([]);
        setCurriculumMessage(
          rows.length
            ? ""
            : "لم يتم إعداد دروس هذه المادة بعد — تواصل مع إدارة المدرسة"
        );
      } catch (error) {
        if (cancelled) return;
        setUnits([]);
        setLessons([]);
        setCurriculumMessage(
          error?.response?.data?.message ||
            error?.message ||
            "تعذر تحميل بيانات مادة وصف الحصة"
        );
      } finally {
        if (!cancelled) setCurriculumLoading(false);
      }
    };

    run();
    return () => {
      cancelled = true;
    };
  }, [form.lecture]);

  useEffect(() => {
    if (!form.unitId) {
      setLessons([]);
      return;
    }
    let active = true;
    const run = async () => {
      setCurriculumLoading(true);
      const response = await fetchCurriculumLessons(form.unitId);
      if (!active) return;
      if (response?.status) {
        setLessons(extractList(response, ["lessons"]));
      } else {
        setLessons([]);
        toast.error(response?.message || "تعذر تحميل الدروس");
      }
      setCurriculumLoading(false);
    };
    run();
    return () => {
      active = false;
    };
  }, [form.unitId]);

  useEffect(() => {
    const selectedLessonId = normalizeId(form.lessonId);
    if (!selectedLessonId || normalizeId(form.unitId) || !units.length) {
      return undefined;
    }

    let active = true;

    const recoverUnitForLesson = async () => {
      for (const unit of units) {
        const unitId = normalizeId(unit);
        if (!unitId) continue;

        const response = await fetchCurriculumLessons(unitId);
        if (!active) return;
        if (!response?.status) continue;

        const unitLessons = extractList(response, ["lessons"]);
        const selectedLesson = unitLessons.find(
          (lesson) => normalizeId(lesson) === selectedLessonId
        );

        if (!selectedLesson) continue;

        setLessons(unitLessons);
        setForm((current) => ({
          ...current,
          unitId,
          lessonId: selectedLessonId,
          lessonTitle: current.lessonTitle || getName(selectedLesson),
        }));
        return;
      }
    };

    recoverUnitForLesson();
    return () => {
      active = false;
    };
  }, [form.lessonId, form.unitId, units]);

  useEffect(() => {
    if (!form.lessonId) return;
    const selected = lessons.find(
      (item) =>
        normalizeId(item) ===
        normalizeId(form.lessonId)
    );
    if (!selected) return;

    const title = getName(selected);
    if (title && title !== form.lessonTitle) {
      setForm((current) => ({
        ...current,
        lessonTitle: title,
      }));
    }
  }, [form.lessonId, form.lessonTitle, lessons]);

  useEffect(() => {
    if (!subject.offeringId) {
      setLibraryItems([]);
      return;
    }

    let active = true;

    const run = async () => {
      setLibraryLoading(true);

      const response =
        await fetchLibraries(
          {
            subjectOfferingId:
              subject.offeringId,
            limit: 500,
          },
          { force: true }
        );

      if (!active) return;

      if (response?.status) {
        setLibraryItems(
          extractList(
            response,
            [
              "library",
              "libraries",
              "items",
            ]
          )
        );
      } else {
        setLibraryItems([]);
      }

      setLibraryLoading(false);
    };

    run();

    return () => {
      active = false;
    };
  }, [subject.offeringId]);

  const createDraftRecord = useCallback(
    async ({ silent = false } = {}) => {
      const existingPreparationId = normalizeId(
        preparationIdRef.current || preparationId
      );

      if (existingPreparationId) {
        return existingPreparationId;
      }

      const lectureId =
        normalizeId(form.lecture);

      if (!lectureId) {
        if (!silent) {
          toast.error(
            "اختر الحصة الدراسية أولًا"
          );
        }
        return false;
      }

      if (
        silent &&
        autosaveCreateBlockedRef.current
      ) {
        return false;
      }

      if (createDraftPromiseRef.current) {
        return createDraftPromiseRef.current;
      }

      if (!silent) {
        autosaveCreateBlockedRef.current = false;
      }

      const createPromise = (async () => {
        const response =
          await addPreparation({
            lecture: lectureId,
          });

        if (!response?.status) {
          if (
            !response?.statusCode ||
            Number(response.statusCode) >= 500
          ) {
            /*
             * لا نعيد POST تلقائيًا بعد فشل شبكة مبهم؛
             * المستخدم يستطيع المحاولة يدويًا بعد التحقق.
             */
            autosaveCreateBlockedRef.current = true;
          }

          if (!silent) {
            toast.error(
              response?.message ||
                "تعذر إنشاء مسودة التحضير"
            );
          }
          return false;
        }

        const created =
          response?.data &&
          !Array.isArray(response.data) &&
          typeof response.data === "object"
            ? response.data
            : extractEntity(response);

        let id = normalizeId(
          created?._id || created?.id
        );

        /*
         * lectureId و preparationId كيانان مختلفان تمامًا.
         * لا نستخدم معرّف الحصة إطلاقًا كمعرّف للتحضير.
         * لو response قديم/غير متوقع لم يرجع _id واضحًا، نبحث عن
         * المسودة التي أنشئت لهذه الحصة بدل PATCH على lectureId.
         */
        if (!id || id === lectureId) {
          const lookupResponse =
            await fetchPreparations({
              lectureId,
              limit: 20,
            });

          if (lookupResponse?.status) {
            const matches = extractList(
              lookupResponse,
              ["preparations"]
            );

            const matchingPreparation =
              matches.find((item) =>
                normalizeId(
                  item?.lecture || item?.lectureId
                ) === lectureId
              );

            id = normalizeId(
              matchingPreparation?._id ||
                matchingPreparation?.id
            );
          }
        }

        if (!id || id === lectureId) {
          if (!silent) {
            toast.error(
              "تم إنشاء المسودة لكن لم يرجع معرّف التحضير الصحيح"
            );
          }
          return false;
        }

        // Persist the id synchronously before React schedules a re-render.
        // This prevents a step-change/resource action/autosave from issuing
        // a second POST /preparation in the small state-update window.
        preparationIdRef.current = id;

        if (mountedRef.current) {
          setPreparationId(id);
          setPreparationStatus(
            getStatus(created)
          );
        }

        autosaveCreateBlockedRef.current = false;
        return id;
      })();

      createDraftPromiseRef.current =
        createPromise;

      try {
        return await createPromise;
      } finally {
        createDraftPromiseRef.current = null;
      }
    },
    [form.lecture, preparationId]
  );

  const saveDraft = useCallback(
    async ({ silent = false } = {}) => {
      if (readOnly) {
        return preparationIdRef.current || preparationId || false;
      }

      // Serialize every save operation. React state updates are asynchronous,
      // so relying on `saving` alone can allow two handlers to enter together.
      if (savePromiseRef.current) {
        return savePromiseRef.current;
      }

      const lectureId = normalizeId(form.lecture);

      if (!lectureId) {
        if (!silent) {
          toast.error("اختر الحصة الدراسية أولًا");
        }
        return false;
      }

      const savePromise = (async () => {
        setSaving(true);

        try {
          let id = normalizeId(
            preparationIdRef.current || preparationId
          );
          const hadContentChanges =
            snapshot(form) !== savedSnapshotRef.current;

          if (!id) {
            id = await createDraftRecord({ silent });

            if (!id) {
              return false;
            }
          }

          // Keep the synchronous ref authoritative for all subsequent actions.
          preparationIdRef.current = normalizeId(id);

          // Safety guard: never PATCH /preparation/:lectureId.
          if (normalizeId(id) === lectureId) {
            if (!silent) {
              toast.error(
                "تعذر تحديد معرّف مسودة التحضير — أعد فتح الصفحة"
              );
            }
            return false;
          }

          let lastResponse = null;

          if (hadContentChanges) {
            const payload = makeChangedPayload(
              form,
              savedSnapshotRef.current
            );

            if (Object.keys(payload).length) {
              lastResponse = await editPreparation(payload, id);

              if (!lastResponse?.status) {
                if (!silent) {
                  toast.error(
                    lastResponse?.message || "تعذر حفظ المسودة"
                  );
                }
                return false;
              }
            }
          }

          if (attachment && id) {
            const uploadResponse = await addPreparationFiles(id, attachment);

            if (!uploadResponse?.status) {
              if (!silent) {
                toast.error(
                  uploadResponse?.message ||
                    "تم حفظ المسودة لكن تعذر رفع المرفق"
                );
              }
              return false;
            }

            const uploadedFile = attachment;

            setAttachment(null);
            setExistingFiles((current) => [
              ...current,
              {
                name: uploadedFile.name,
                size: uploadedFile.size,
              },
            ]);

            lastResponse = uploadResponse;
          }

          const savedEntity = extractEntity(lastResponse || {});
          const responseStatus = Object.keys(savedEntity).length
            ? getStatus(savedEntity)
            : "draft";

          savedSnapshotRef.current = snapshot(form);
          lastSaveRef.current = new Date();
          setPreparationStatus(responseStatus);

          if (!silent) {
            toast.success("تم حفظ المسودة");
          }

          return id;
        } catch (error) {
          if (!silent) {
            toast.error(
              error?.response?.data?.message || "تعذر حفظ المسودة"
            );
          }
          return false;
        } finally {
          if (mountedRef.current) {
            setSaving(false);
          }
        }
      })();

      savePromiseRef.current = savePromise;

      try {
        return await savePromise;
      } finally {
        if (savePromiseRef.current === savePromise) {
          savePromiseRef.current = null;
        }
      }
    },
    [
      attachment,
      createDraftRecord,
      form,
      preparationId,
      readOnly,
    ]
  );

  // Step navigation must never persist data by itself.
  // Drafts are saved only from the explicit "حفظ كمسودة" action, while
  // "إرسال للمراجعة" persists the latest form data and then submits it.
  const changeStep = (nextStep) => {
    if (nextStep === step) return;

    setStep(nextStep);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const addObjective = () => updateForm({ objectives: [...form.objectives, ""] });
  const updateObjective = (index, value) => {
    const next = [...form.objectives];
    next[index] = value;
    updateForm({ objectives: next });
  };
  const deleteObjective = (index) => {
    const next = form.objectives.filter((_, rowIndex) => rowIndex !== index);
    updateForm({ objectives: next.length ? next : [""] });
  };

  const handleLessonSelection = (lessonIdValue) => {
    const nextLessonId =
      normalizeId(lessonIdValue);
    const selected =
      lessons.find(
        (item) =>
          normalizeId(item) ===
          nextLessonId
      );

    if (!selected) {
      updateForm({
        lessonId: "",
        lessonTitle: "",
      });
      setSuggestedObjectives(false);
      return;
    }

    const suggestions =
      normalizeObjectiveRows(
        selected?.objectives
      )
        .map((item) =>
          String(item || "").trim()
        )
        .filter(Boolean);
    const currentObjectives =
      form.objectives
        .map((item) =>
          String(item || "").trim()
        )
        .filter(Boolean);
    const changingLesson =
      Boolean(form.lessonId) &&
      normalizeId(form.lessonId) !==
        nextLessonId;

    let objectives =
      form.objectives;
    let usingSuggestions = false;

    if (
      currentObjectives.length === 0
    ) {
      objectives =
        suggestions.length
          ? suggestions
          : [""];
      usingSuggestions =
        suggestions.length > 0;
    } else if (changingLesson) {
      const replace =
        window.confirm(
          "تم تغيير الدرس. هل تريد استخدام الأهداف المقترحة للدرس الجديد؟\n\nاضغط إلغاء للاحتفاظ بالأهداف الحالية."
        );

      if (replace) {
        objectives =
          suggestions.length
            ? suggestions
            : [""];
        usingSuggestions =
          suggestions.length > 0;
      }
    }

    objectivePrefillLessonRef.current =
      nextLessonId;
    setSuggestedObjectives(
      usingSuggestions
    );
    updateForm({
      lessonId: nextLessonId,
      lessonTitle:
        getName(selected),
      objectives,
    });
  };

  const toggleLibraryItem = (id) => {
    const next = new Set(form.digitalContentIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    updateForm({ digitalContentIds: Array.from(next) });
  };

  const saveLibraryItem = async () => {
    if (librarySaving) return;
    setLibrarySaving(true);
    const response = await addLibraryResource({
      ...libraryDraft,
      subjectId: subject.id,
      subjectOfferingId: subject.offeringId,
    });
    setLibrarySaving(false);
    if (!response?.status) {
      toast.error(response?.message || "تعذر إضافة المحتوى");
      return;
    }
    const created = extractEntity(response);
    const id = normalizeId(created);
    if (id) {
      setLibraryItems((current) => [created, ...current.filter((item) => normalizeId(item) !== id)]);
      updateForm({ digitalContentIds: Array.from(new Set([...form.digitalContentIds, id])) });
    }
    setLibraryDraft({ title: "", link: "", file: null });
    setLibraryDialog(false);
    toast.success("تمت إضافة المحتوى إلى مكتبة المدرسة");
  };

  const refreshResourceState = useCallback(
    async (idValue, { preserveExistingOnEmpty = false } = {}) => {
      const id = normalizeId(idValue);
      if (!id) return false;

      const response =
        await fetchSinglePreparation(id);

      if (!response?.status) {
        return false;
      }

      const entity =
        extractEntity(response);
      const hasResourcesField =
        Array.isArray(entity?.resources);

      if (hasResourcesField) {
        const grouped =
          groupResources(entity.resources);
        const serverCount =
          Object.values(grouped).reduce(
            (total, items) => total + items.length,
            0
          );

        /*
         * بعد POST /resources قد يرجع GET /preparation/:id للحظات بدون
         * الـ resource الجديد. لا نمسح العنصر الذي أضفناه من الواجهة في
         * هذه الحالة؛ نثق في POST 201 ونترك الـ refresh التالي يصالح الحالة.
         */
        if (!(preserveExistingOnEmpty && serverCount === 0)) {
          setForm((current) => ({
            ...current,
            ...grouped,
          }));
        }
      }

      setPreparationStatus(
        getStatus(entity)
      );

      return entity;
    },
    []
  );

  const applyCreatedResource = useCallback(
    (response, groupKey, fallbackPayload = {}) => {
      const created = extractEntity(response);
      const candidate =
        created &&
        typeof created === "object" &&
        !Array.isArray(created)
          ? { ...fallbackPayload, ...created }
          : fallbackPayload;

      const normalized =
        normalizeAssignmentItems([candidate])[0];

      if (!normalized) return;

      setForm((current) => {
        const currentItems = Array.isArray(current[groupKey])
          ? current[groupKey]
          : [];
        const resourceId = normalizeId(
          normalized.resourceId || normalized.id
        );
        const withoutDuplicate = resourceId
          ? currentItems.filter(
              (item) =>
                normalizeId(item?.resourceId || item?.id) !== resourceId
            )
          : currentItems;

        return {
          ...current,
          [groupKey]: [...withoutDuplicate, normalized],
        };
      });
    },
    []
  );

  const ensureDraftForResource = async () => {
    if (preparationId) {
      return preparationId;
    }

    const id =
      await createDraftRecord({
        silent: false,
      });

    return normalizeId(id);
  };

  const matchesPreparationContext = (item) => {
    const offeringId = normalizeId(
      item?.subjectOfferingId ||
        item?.subjectOffering ||
        item?.offeringId ||
        item?.offering
    );
    const classId =
      getLectureClassId(
        lecture || {}
      );
    const itemClassIds = (
      Array.isArray(item?.classIds)
        ? item.classIds
        : item?.classId
          ? [item.classId]
          : item?.class
            ? [item.class]
            : []
    )
      .map(normalizeId)
      .filter(Boolean);

    const offeringMatches =
      !subject.offeringId
        ? true
        : offeringId ===
          subject.offeringId;
    const classMatches =
      !classId
        ? true
        : itemClassIds.includes(
            classId
          );

    return (
      offeringMatches &&
      classMatches
    );
  };

  const openAssignment = async (groupKey) => {
    setAssignmentDialog(groupKey);
    setAssignmentEditIndex(null);
    setAssignmentDraft({
      title: "",
      description: "",
      startDate: "",
      endDate: "",
      totalGrade: "",
      link: "",
    });

    if (groupKey === "exams") {
      setExamLoading(true);

      const filters = {
        ...(subject.offeringId
          ? {
              subjectOfferingId:
                subject.offeringId,
            }
          : {}),
        ...(getLectureClassId(
          lecture || {}
        )
          ? {
              classIds:
                getLectureClassId(
                  lecture || {}
                ),
            }
          : {}),
      };

      const response =
        role === "TEACHER"
          ? await fetchTeacherExams(
              filters
            )
          : await fetchExams(
              filters
            );

      setExamOptions(
        response?.status
          ? extractList(
              response,
              ["exams"]
            ).filter(
              matchesPreparationContext
            )
          : []
      );
      setExamLoading(false);
    }

    if (groupKey === "activities") {
      setProjectLoading(true);

      const response =
        role === "TEACHER"
          ? await fetchTeacherProjects()
          : await fetchProjects();

      setProjectOptions(
        extractList(
          response,
          ["projects"]
        ).filter(
          matchesPreparationContext
        )
      );
      setProjectLoading(false);
    }
  };

  const addExistingExam = async (exam) => {
    if (resourceSaving) return;

    const id =
      await ensureDraftForResource();
    if (!id) return;

    setResourceSaving(true);

    const response =
      await addPreparationResource(
        id,
        {
          type: "quiz",
          examId:
            normalizeId(exam),
        }
      );

    setResourceSaving(false);

    if (!response?.status) {
      toast.error(
        response?.message ||
          "تعذر ربط الاختبار بالتحضير"
      );
      return;
    }

    applyCreatedResource(
      response,
      "exams",
      {
        type: "quiz",
        examId: normalizeId(exam),
        title: getName(exam, exam?.examTitle || "اختبار"),
      }
    );
    await refreshResourceState(id, { preserveExistingOnEmpty: true });
    setAssignmentDialog(null);
    toast.success(
      "تمت إضافة الاختبار للتحضير"
    );
  };

  const addExistingProject = async (project) => {
    if (resourceSaving) return;

    const id =
      await ensureDraftForResource();
    if (!id) return;

    setResourceSaving(true);

    const response =
      await addPreparationResource(
        id,
        {
          type: "activity",
          projectId:
            normalizeId(project),
        }
      );

    setResourceSaving(false);

    if (!response?.status) {
      toast.error(
        response?.message ||
          "تعذر ربط النشاط بالتحضير"
      );
      return;
    }

    applyCreatedResource(
      response,
      "activities",
      {
        type: "activity",
        projectId: normalizeId(project),
        title: getName(project, "نشاط / مشروع"),
      }
    );
    await refreshResourceState(id, { preserveExistingOnEmpty: true });
    setAssignmentDialog(null);
    toast.success(
      "تمت إضافة النشاط للتحضير"
    );
  };

  const editAssignment = (groupKey, index) => {
    const item =
      form[groupKey]?.[index];
    if (!item) return;

    setAssignmentDialog(groupKey);
    setAssignmentEditIndex(index);
    setAssignmentDraft({
      title: item.title || "",
      description:
        item.description || "",
      startDate:
        item.startDate || "",
      endDate:
        item.endDate || "",
      totalGrade:
        item.totalGrade ?? "",
      link: item.link || "",
    });
  };

  const addCustomAssignment = async () => {
    const group =
      ASSIGNMENT_GROUPS.find(
        (item) =>
          item.key ===
          assignmentDialog
      );

    if (!group || resourceSaving) {
      return;
    }

    const title =
      String(
        assignmentDraft.title || ""
      ).trim();

    if (!title) {
      toast.error(
        "اكتب عنوان التكليف"
      );
      return;
    }

    if (
      assignmentDraft.startDate &&
      assignmentDraft.endDate &&
      assignmentDraft.endDate <
        assignmentDraft.startDate
    ) {
      toast.error(
        "تاريخ النهاية يجب ألا يسبق البداية"
      );
      return;
    }

    const id =
      await ensureDraftForResource();
    if (!id) return;

    const payload = {
      type:
        RESOURCE_TYPE_BY_GROUP[
          group.key
        ],
      title,
      ...(String(
        assignmentDraft.description || ""
      ).trim()
        ? {
            description:
              String(
                assignmentDraft.description
              ).trim(),
          }
        : {}),
      ...(assignmentDraft.startDate
        ? {
            startAt:
              dateOnlyToIso(
                assignmentDraft.startDate
              ),
          }
        : {}),
      ...(assignmentDraft.endDate
        ? {
            dueAt:
              dateOnlyToIso(
                assignmentDraft.endDate,
                true
              ),
          }
        : {}),
      ...(String(
        assignmentDraft.totalGrade ?? ""
      ).trim() !== ""
        ? {
            totalGrade:
              Number(
                assignmentDraft.totalGrade
              ),
          }
        : {}),
      ...(String(
        assignmentDraft.link || ""
      ).trim()
        ? {
            link:
              String(
                assignmentDraft.link
              ).trim(),
          }
        : {}),
    };

    const oldItem =
      Number.isInteger(
        assignmentEditIndex
      )
        ? form[group.key]?.[
            assignmentEditIndex
          ]
        : null;

    setResourceSaving(true);

    const createResponse =
      await addPreparationResource(
        id,
        payload
      );

    if (!createResponse?.status) {
      setResourceSaving(false);
      toast.error(
        createResponse?.message ||
          "تعذر إضافة التكليف"
      );
      return;
    }

    // POST نجح بالفعل؛ اعرض التكليف فورًا بدل انتظار GET detail.
    applyCreatedResource(
      createResponse,
      group.key,
      payload
    );

    if (oldItem?.resourceId) {
      const deleteResponse =
        await deletePreparationResource(
          id,
          oldItem.resourceId
        );

      if (!deleteResponse?.status) {
        setResourceSaving(false);
        await refreshResourceState(id);
        toast.warning(
          "تم إنشاء النسخة الجديدة، لكن تعذر حذف التكليف القديم"
        );
        setAssignmentDialog(null);
        setAssignmentEditIndex(null);
        return;
      }
    }

    setResourceSaving(false);
    await refreshResourceState(id, { preserveExistingOnEmpty: true });
    setAssignmentDialog(null);
    setAssignmentEditIndex(null);
    toast.success(
      oldItem
        ? "تم استبدال التكليف"
        : "تمت إضافة التكليف"
    );
  };

  const removeAssignment = async (
    groupKey,
    index
  ) => {
    const item =
      form[groupKey]?.[index];
    const resourceId =
      normalizeId(
        item?.resourceId ||
          item?._id
      );

    if (!resourceId) {
      return;
    }

    if (resourceSaving) return;

    setResourceSaving(true);

    const response =
      await deletePreparationResource(
        preparationId,
        resourceId
      );

    setResourceSaving(false);

    if (!response?.status) {
      toast.error(
        response?.message ||
          "تعذر حذف التكليف"
      );
      return;
    }

    await refreshResourceState(
      preparationId
    );
    toast.success(
      "تم حذف التكليف"
    );
  };

  const validateForSubmit = () => {
    const errors = [];
    if (!normalizeId(form.lessonId)) {
      errors.push({
        message: "اختر درسًا من المنهج",
        target: "lesson-section",
        step: 1,
      });
    }
    if (!form.objectives.some((item) => String(item || "").trim())) {
      errors.push({ message: "أضف هدفاً واحداً على الأقل", target: "objectives-section", step: 1 });
    }
    if (!form.digitalContentIds.length) {
      errors.push({ message: "اختر المحتوى الرقمي المرتبط بالدرس", target: "digital-content-section", step: 1 });
    }
    if (!assignmentCount(form)) {
      errors.push({ message: "أضف إثراء أو واجب أو اختبار أو نشاط", target: "assignments-section", step: 2 });
    }
    return errors;
  };

  const jumpToError = (error) => {
    setStep(error.step);
    window.setTimeout(() => {
      document.getElementById(error.target)?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 80);
  };

  const handleSubmitForReview = async () => {
    const errors = validateForSubmit();
    setValidationErrors(errors);
    if (errors.length) {
      jumpToError(errors[0]);
      return;
    }

    setSubmitting(true);
    try {
      let id = preparationId;
      if (dirty || !id) {
        const savedId = await saveDraft({ silent: true });
        if (!savedId) return;
        id = normalizeId(savedId) || preparationId || id;
      }

      if (!id) {
        toast.error("تعذر تحديد المسودة بعد الحفظ");
        return;
      }

      const response = await submitPreparation(id);
      if (!response?.status) {
        toast.error(response?.message || "تعذر إرسال التحضير للمراجعة");
        return;
      }
      setPreparationId(id);
      setPreparationStatus("pending");
      savedSnapshotRef.current = snapshot(form);
      setValidationErrors([]);
      clearDraftCache(form.lecture);
      toast.success("تم إرسال التحضير للمراجعة");
    } finally {
      setSubmitting(false);
    }
  };

  const handleApprovePreparation = async () => {
    const id = normalizeId(preparationIdRef.current || preparationId);
    if (!id || reviewing) return;

    setReviewing(true);
    try {
      const response = await reviewPreparation(id, {
        reviewStatus: "approved",
      });

      if (!response?.status) {
        toast.error(response?.message || "تعذر اعتماد التحضير");
        return;
      }

      const reviewedEntity = extractEntity(response);
      setPreparationStatus("approved");
      setPreparationRecord((current) => ({
        ...(current || {}),
        ...(reviewedEntity || {}),
        reviewStatus: "approved",
      }));
      setReviewNote("");
      toast.success("تم اعتماد التحضير");
    } finally {
      setReviewing(false);
    }
  };

  const handleRequestRevision = async () => {
    const id = normalizeId(preparationIdRef.current || preparationId);
    if (!id || reviewing) return;

    setReviewing(true);
    try {
      const response = await reviewPreparation(id, {
        reviewStatus: "needs_revision",
        reviewNote: reviewDraft,
      });

      if (!response?.status) {
        toast.error(response?.message || "تعذر طلب التعديل");
        return;
      }

      const reviewedEntity = extractEntity(response);
      setPreparationStatus("needs_revision");
      setPreparationRecord((current) => ({
        ...(current || {}),
        ...(reviewedEntity || {}),
        reviewStatus: "needs_revision",
        reviewNote: reviewDraft.trim(),
      }));
      setReviewNote(reviewDraft.trim());
      setReviewDialog(false);
      setReviewDraft("");
      toast.success("تم إرسال التحضير للمعلم للتعديل");
    } finally {
      setReviewing(false);
    }
  };

  const handleAttachment = (event) => {
    const file = event.target.files?.[0] || null;
    event.target.value = "";
    if (!file) return;
    if (file.size > MAX_ATTACHMENT_SIZE) {
      toast.error("حجم المرفق يجب ألا يتجاوز 20 ميجابايت");
      return;
    }
    setAttachment(file);
  };

  if (loading) return <Loading />;

  const selectedLibraryItems = libraryItems.filter((item) => form.digitalContentIds.includes(normalizeId(item)));
  const filteredLibraryItems = libraryItems.filter((item) =>
    getName(item).toLowerCase().includes(librarySearch.trim().toLowerCase())
  );
  const statusMeta = STATUS_META[preparationStatus] || STATUS_META.draft;

  if (mode === "view") {
    return (
      <PreparationPageWrapper teacherPortal={teacherPortal}>
        <PreparationDocumentView
          form={form}
          subject={subject}
          grade={grade}
          lecture={lecture}
          units={units}
          lessons={lessons}
          libraryItems={libraryItems}
          existingFiles={existingFiles}
          preparationRecord={preparationRecord}
          preparationStatus={preparationStatus}
          reviewNote={reviewNote}
          canReview={canReview}
          reviewing={reviewing}
          onApprove={handleApprovePreparation}
          onRequestRevision={() => {
            setReviewDraft("");
            setReviewDialog(true);
          }}
          onBack={goBack}
        />

        <Dialog
          open={reviewDialog}
          onClose={() => !reviewing && setReviewDialog(false)}
          fullWidth
          maxWidth="sm"
          dir="rtl"
        >
          <DialogTitle sx={{ fontWeight: 900 }}>طلب تعديل التحضير</DialogTitle>
          <DialogContent>
            <Typography sx={{ color: "var(--color-muted)", fontSize: 11, mb: 1 }}>
              اكتب ملاحظة واضحة للمعلم توضح المطلوب تعديله.
            </Typography>
            <TextField
              autoFocus
              fullWidth
              multiline
              minRows={4}
              value={reviewDraft}
              onChange={(event) => setReviewDraft(event.target.value)}
              inputProps={{ maxLength: 1000 }}
              placeholder="مثال: يرجى توضيح الأهداف وإضافة نشاط مناسب للدرس"
            />
          </DialogContent>
          <DialogActions>
            <Button
              onClick={() => setReviewDialog(false)}
              disabled={reviewing}
              sx={{ fontWeight: 800, textTransform: "none" }}
            >
              إلغاء
            </Button>
            <Button
              variant="contained"
              onClick={handleRequestRevision}
              disabled={reviewing}
              sx={{ fontWeight: 900, textTransform: "none" }}
            >
              {reviewing ? "جاري الحفظ..." : "إرسال طلب التعديل"}
            </Button>
          </DialogActions>
        </Dialog>
      </PreparationPageWrapper>
    );
  }

  return (
    <PreparationPageWrapper teacherPortal={teacherPortal}>
      <Box dir="rtl" sx={{ pb: 4 }}>
        <Paper
          elevation={0}
          sx={{
            mb: 1.1,
            px: { xs: 1.2, md: 1.6 },
            py: 1.15,
            borderRadius: "18px",
            color: "#fff",
            background: "linear-gradient(115deg, #173f65 0%, #285f8d 100%)",
          }}
        >
          <Stack direction={{ xs: "column", sm: "row" }} alignItems={{ xs: "stretch", sm: "center" }} justifyContent="space-between" gap={1}>
            <Stack direction="row" alignItems="center" gap={1}>
              <IconButton onClick={goBack} sx={{ color: "#fff", border: "1px solid rgba(255,255,255,.2)" }}>
                <ArrowBackRounded />
              </IconButton>
              <Box>
                <Typography sx={{ fontSize: { xs: 17, md: 20 }, fontWeight: 900 }}>
                  {mode === "create" ? "تحضير درس جديد" : mode === "view" ? "عرض التحضير" : "تعديل التحضير"}
                </Typography>
                <Typography sx={{ color: "rgba(255,255,255,.72)", fontSize: 10.5 }}>
                  تحضير منظم خطوة بخطوة — يتم حفظ المسودة تلقائيًا كل 30 ثانية
                </Typography>
              </Box>
            </Stack>
            <Stack direction="row" alignItems="center" gap={0.7}>
              <Chip label={statusMeta.label} color={statusMeta.tone} size="small" sx={{ fontWeight: 900 }} />
              {saving && <Chip label="جاري الحفظ..." size="small" sx={{ bgcolor: "rgba(255,255,255,.12)", color: "#fff" }} />}
              {!saving && lastSaveRef.current && <Chip label="تم حفظ المسودة" size="small" icon={<CheckCircleRounded />} sx={{ bgcolor: "rgba(255,255,255,.12)", color: "#fff", "& .MuiChip-icon": { color: "#fff" } }} />}
            </Stack>
          </Stack>
        </Paper>

        {reviewNote && preparationStatus === "needs_revision" && (
          <Alert severity="warning" icon={<WarningAmberRounded />} sx={{ mb: 1.1, borderRadius: "14px", fontWeight: 800 }}>
            <strong>ملاحظة المراجع:</strong> {reviewNote}
          </Alert>
        )}

        {canReview && (
          <Paper
            elevation={0}
            sx={{
              mb: 1.1,
              p: 1.1,
              border: "1px solid rgba(36,74,112,.09)",
              borderRadius: "16px",
              bgcolor: "var(--color-cream)",
            }}
          >
            <Stack
              direction={{ xs: "column", sm: "row" }}
              alignItems={{ xs: "stretch", sm: "center" }}
              justifyContent="space-between"
              gap={1}
            >
              <Box>
                <Typography sx={{ fontWeight: 900, color: "var(--color-navy-deep)" }}>
                  مراجعة التحضير
                </Typography>
                <Typography sx={{ mt: 0.2, color: "var(--color-muted)", fontSize: 10.5 }}>
                  التحضير بانتظار قرار المراجع. يمكنك اعتماده أو إعادته للمعلم مع ملاحظة.
                </Typography>
              </Box>
              <Stack direction={{ xs: "column", sm: "row" }} gap={0.7}>
                <Button
                  variant="contained"
                  startIcon={<CheckCircleRounded />}
                  disabled={reviewing}
                  onClick={handleApprovePreparation}
                  sx={{
                    fontWeight: 900,
                    textTransform: "none",
                    bgcolor: "#238f55",
                  }}
                >
                  اعتماد التحضير
                </Button>
                <Button
                  variant="outlined"
                  startIcon={<EditNoteRounded />}
                  disabled={reviewing}
                  onClick={() => {
                    setReviewDraft("");
                    setReviewDialog(true);
                  }}
                  sx={{
                    fontWeight: 900,
                    textTransform: "none",
                    color: "var(--color-gold-dark)",
                    borderColor: "rgba(211,164,79,.45)",
                  }}
                >
                  طلب تعديل
                </Button>
              </Stack>
            </Stack>
          </Paper>
        )}

        <WizardSteps step={step} onStep={changeStep} stepTwoEnabled={Boolean(preparationId) || mode !== "create"} />
        <PreparationProgress
          form={form}
          step={step}
          assignmentTotal={assignmentCount(form)}
        />

        <Stack spacing={1.15} mt={1.05}>
          <SectionCard
            id="lesson-section"
            title="الدرس"
            subtitle="المادة والصف من الحصة الدراسية، ويمكنك اختيار الوحدة والدرس فقط."
            icon={<MenuBookRounded />}
          >
            {canPickLecture && (
              <TextField
                select
                fullWidth
                size="small"
                label="الحصة الدراسية"
                value={form.lecture}
                onChange={(event) => {
                  setPreparationId("");
                  setPreparationStatus("draft");
                  updateForm({
                    ...EMPTY_FORM,
                    lecture: event.target.value,
                  });
                  setStep(1);
                }}
                sx={{ mb: 1.2 }}
              >
                {lectures.map((item) => (
                  <MenuItem key={normalizeId(item)} value={normalizeId(item)}>
                    {getLectureLabel(item)}
                  </MenuItem>
                ))}
              </TextField>
            )}

            {!form.lecture && (
              <Alert severity="info" sx={{ borderRadius: "12px" }}>
                اختر الحصة أولًا لعرض المنهج الخاص بالمادة والصف.
              </Alert>
            )}

            {form.lecture && (
              <Grid container spacing={1}>
                <Grid item xs={12} md={4}>
                  <TextField fullWidth size="small" label="المادة" value={subject.name} disabled />
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    select
                    fullWidth
                    size="small"
                    label="الوحدة"
                    value={form.unitId}
                    disabled={!editable || curriculumLoading || !units.length}
                    onChange={(event) => {
                      objectivePrefillLessonRef.current = "";
                      setSuggestedObjectives(false);
                      updateForm({ unitId: event.target.value, lessonId: "", lessonTitle: "" });
                    }}
                  >
                    {units.map((item) => (
                      <MenuItem key={normalizeId(item)} value={normalizeId(item)}>
                        {getName(item)}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    select
                    fullWidth
                    size="small"
                    label="الدرس"
                    value={form.lessonId}
                    disabled={!editable || curriculumLoading || !form.unitId || !lessons.length}
                    onChange={(event) =>
                      handleLessonSelection(
                        event.target.value
                      )
                    }
                  >
                    {lessons.map((item) => (
                      <MenuItem key={normalizeId(item)} value={normalizeId(item)}>
                        {getName(item)}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12}>
                  <Typography sx={{ color: "var(--color-muted)", fontSize: 10 }}>
                    الصف: <strong>{grade.name}</strong>
                  </Typography>
                </Grid>
              </Grid>
            )}

            {curriculumMessage && (
              <Alert severity={units.length ? "info" : "warning"} sx={{ mt: 1, borderRadius: "12px" }}>
                {curriculumMessage}
              </Alert>
            )}
          </SectionCard>

          {step === 1 ? (
            <>
              <SectionCard
                title="المعلومات الأساسية"
                subtitle="اكتب ما سيبدأ به الطالب وما يحتاج معرفته قبل الشرح."
                icon={<AutoStoriesRounded />}
              >
                <Grid container spacing={1.2}>
                  <Grid item xs={12} md={6}>
                    <FieldLabel studentVisible>التهيئة</FieldLabel>
                    <TextField
                      fullWidth
                      multiline
                      minRows={4}
                      disabled={!editable}
                      value={form.warmup}
                      onChange={(event) => updateForm({ warmup: event.target.value })}
                      placeholder="أهلاً بكم في درسنا اليوم..."
                    />
                  </Grid>
                  <Grid item xs={12} md={6}>
                    <FieldLabel studentVisible>مفردات الدرس</FieldLabel>
                    <TextField
                      fullWidth
                      multiline
                      minRows={4}
                      disabled={!editable}
                      value={form.vocabulary}
                      onChange={(event) => updateForm({ vocabulary: event.target.value })}
                      placeholder="المفاهيم والمصطلحات التي يقدمها الدرس"
                    />
                  </Grid>
                </Grid>
              </SectionCard>

              <SectionCard
                id="objectives-section"
                title={form.lessonTitle || "أهداف الدرس"}
                subtitle="الأهداف التي سيكتسبها الطالب في الدرس"
                icon={<EditNoteRounded />}
              >
                <FieldLabel studentVisible required>الأهداف التي سيكتسبها الطالب في الدرس</FieldLabel>
                {suggestedObjectives && (
                  <Alert severity="info" sx={{ mb: 1, borderRadius: "12px", fontSize: 11 }}>
                    مقترحة من تحضير سابق لنفس الدرس — عدّلي أو احذفي بحرية
                  </Alert>
                )}
                <Stack spacing={0.75}>
                  {form.objectives.map((objective, index) => (
                    <Stack direction="row" alignItems="center" gap={0.6} key={`objective-${index}`}>
                      <TextField
                        fullWidth
                        size="small"
                        disabled={!editable}
                        value={objective}
                        onChange={(event) => updateObjective(index, event.target.value)}
                        placeholder={`الهدف ${index + 1}`}
                      />
                      {editable && (
                        <IconButton onClick={() => deleteObjective(index)} sx={{ color: "var(--color-danger)" }}>
                          <DeleteOutlineRounded />
                        </IconButton>
                      )}
                    </Stack>
                  ))}
                  {editable && (
                    <Button type="button" startIcon={<AddRounded />} onClick={addObjective} sx={{ alignSelf: "flex-start", fontWeight: 900, textTransform: "none" }}>
                      إضافة هدف
                    </Button>
                  )}
                </Stack>
              </SectionCard>

              <SectionCard
                id="digital-content-section"
                title="المحتوى الرقمي المرتبط بالدرس"
                subtitle="اختر من مكتبة المدرسة، أو أضف رابطًا أو ملفًا دون مغادرة التحضير."
                icon={<LinkRounded />}
              >
                <FieldLabel studentVisible required>المحتوى الرقمي المرتبط بالدرس</FieldLabel>
                <Stack direction={{ xs: "column", sm: "row" }} gap={0.8} mb={1}>
                  <TextField
                    fullWidth
                    size="small"
                    value={librarySearch}
                    onChange={(event) => setLibrarySearch(event.target.value)}
                    placeholder="ابحث في مكتبة المادة"
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start"><SearchRounded fontSize="small" /></InputAdornment>
                      ),
                    }}
                  />
                  {editable && (
                    <Button
                      type="button"
                      variant="outlined"
                      startIcon={<AddRounded />}
                      onClick={() => setLibraryDialog(true)}
                      sx={{ whiteSpace: "nowrap", fontWeight: 900, textTransform: "none" }}
                    >
                      أضف رابط أو ملف
                    </Button>
                  )}
                </Stack>

                {selectedLibraryItems.length > 0 && (
                  <Stack direction="row" flexWrap="wrap" gap={0.6} mb={1}>
                    {selectedLibraryItems.map((item) => {
                      const id = normalizeId(item);
                      return (
                        <Chip
                          key={id}
                          label={getName(item, "محتوى")}
                          onDelete={editable ? () => toggleLibraryItem(id) : undefined}
                          sx={{ fontWeight: 800 }}
                        />
                      );
                    })}
                  </Stack>
                )}

                {libraryLoading ? (
                  <CircularProgress size={24} />
                ) : filteredLibraryItems.length ? (
                  <Stack spacing={0.6} sx={{ maxHeight: 260, overflowY: "auto" }}>
                    {filteredLibraryItems.map((item) => {
                      const id = normalizeId(item);
                      const selected = form.digitalContentIds.includes(id);
                      return (
                        <Paper key={id} variant="outlined" sx={{ p: 0.8, borderRadius: "12px" }}>
                          <Stack direction="row" alignItems="center" justifyContent="space-between" gap={1}>
                            <Box sx={{ minWidth: 0 }}>
                              <Typography noWrap sx={{ color: "var(--color-navy-deep)", fontWeight: 850, fontSize: 11.5 }}>
                                {getName(item, "محتوى رقمي")}
                              </Typography>
                              <Typography noWrap sx={{ color: "var(--color-muted)", fontSize: 9.5 }}>
                                {item?.link || item?.url || item?.fileName || item?.filename || "عنصر من مكتبة المدرسة"}
                              </Typography>
                            </Box>
                            <Button
                              type="button"
                              disabled={!editable}
                              onClick={() => toggleLibraryItem(id)}
                              variant={selected ? "contained" : "outlined"}
                              size="small"
                              sx={{ minWidth: 38, fontWeight: 900 }}
                            >
                              {selected ? "−" : "+"}
                            </Button>
                          </Stack>
                        </Paper>
                      );
                    })}
                  </Stack>
                ) : (
                  <Alert severity="info" sx={{ borderRadius: "12px" }}>
                    لا يوجد محتوى في مكتبة هذه المادة بعد. يمكنك إضافة أول رابط أو ملف من هنا.
                  </Alert>
                )}
              </SectionCard>
            </>
          ) : (
            <>
              <SectionCard
                title="طرق تنفيذ الدرس"
                subtitle="هذه الخيارات تظهر للمعلم والمشرف فقط."
                icon={<AutoStoriesRounded />}
              >
                <Grid container spacing={1.5}>
                  <Grid item xs={12} md={6}>
                    <FieldLabel>استراتيجيات التدريس</FieldLabel>
                    <ChoiceChecklist
                      options={referenceLists.strategies}
                      values={form.teachingStrategies}
                      disabled={!editable}
                      onChange={(value) => updateForm({ teachingStrategies: value })}
                      otherValue={form.otherTeachingStrategy}
                      onOtherChange={(value) => updateForm({ otherTeachingStrategy: value })}
                    />
                  </Grid>
                  <Grid item xs={12} md={6}>
                    <FieldLabel>الوسائل التعليمية المستخدمة</FieldLabel>
                    <ChoiceChecklist
                      options={referenceLists.aids}
                      values={form.educationalAids}
                      disabled={!editable}
                      onChange={(value) => updateForm({ educationalAids: value })}
                      otherValue={form.otherEducationalAid}
                      onOtherChange={(value) => updateForm({ otherEducationalAid: value })}
                    />
                  </Grid>
                </Grid>
              </SectionCard>

              <SectionCard title="إكمال الدرس" icon={<CheckCircleRounded />}>
                <Grid container spacing={1.2}>
                  <Grid item xs={12} md={6}>
                    <FieldLabel studentVisible>مهارات التفكير</FieldLabel>
                    <TextField fullWidth multiline minRows={4} disabled={!editable} value={form.thinkingSkills} onChange={(event) => updateForm({ thinkingSkills: event.target.value })} />
                  </Grid>
                  <Grid item xs={12} md={6}>
                    <FieldLabel studentVisible>إغلاق الدرس</FieldLabel>
                    <TextField fullWidth multiline minRows={4} disabled={!editable} value={form.lessonClosing} onChange={(event) => updateForm({ lessonClosing: event.target.value })} />
                  </Grid>
                </Grid>
              </SectionCard>

              <SectionCard
                id="assignments-section"
                title="تكليفات الحصة"
                subtitle="يجب إضافة نوع واحد على الأقل قبل الإرسال للمراجعة."
                icon={<MenuBookRounded />}
              >
                <Alert severity="info" sx={{ mb: 1.2, borderRadius: "12px", fontWeight: 900 }}>
                  يتعين عليك إضافة إثراء أو واجب أو اختبار أو نشاط واحد على الأقل *
                </Alert>
                <Grid container spacing={1}>
                  {ASSIGNMENT_GROUPS.map((group) => (
                    <Grid item xs={12} md={6} key={group.key}>
                      <Paper variant="outlined" sx={{ p: 1, borderRadius: "14px", height: "100%" }}>
                        <Stack direction="row" alignItems="center" justifyContent="space-between" mb={0.8}>
                          <Stack direction="row" alignItems="center" gap={0.6}>
                            <Typography sx={{ color: "var(--color-navy-deep)", fontWeight: 900, fontSize: 12 }}>
                              {group.label}
                            </Typography>
                            <StudentBadge />
                          </Stack>
                          {editable && (
                            <Button size="small" startIcon={<AddRounded />} onClick={() => openAssignment(group.key)} sx={{ fontWeight: 900, textTransform: "none" }}>
                              إضافة
                            </Button>
                          )}
                        </Stack>
                        <Stack spacing={0.55}>
                          {form[group.key].length ? (
                            form[group.key].map((item, index) => (
                              <AssignmentCard
                                key={`${group.key}-${item.id || index}`}
                                item={item}
                                group={group}
                                readOnly={!editable}
                                onRemove={() => removeAssignment(group.key, index)}
                                onEdit={() => {
                                  if (item.examId) {
                                    navigateAway(
                                      role === "TEACHER"
                                        ? `/teacher/exams/edit/${item.examId}`
                                        : `/school/exams/edit/${item.examId}`
                                    );
                                    return;
                                  }

                                  if (item.projectId) {
                                    navigateAway(
                                      role === "TEACHER"
                                        ? `/teacher/projects`
                                        : `/school/projects/edit/${item.projectId}`
                                    );
                                    return;
                                  }

                                  editAssignment(group.key, index);
                                }}
                                onAnswers={
                                  item.examId
                                    ? () =>
                                        navigateAway(
                                          role === "TEACHER"
                                            ? `/teacher/grading/exams?examId=${item.examId}`
                                            : `/school/exams/${item.examId}`
                                        )
                                    : undefined
                                }
                              />
                            ))
                          ) : (
                            <Typography sx={{ color: "var(--color-muted)", fontSize: 10.5, py: 1 }}>
                              لا توجد عناصر مضافة
                            </Typography>
                          )}
                        </Stack>
                      </Paper>
                    </Grid>
                  ))}
                </Grid>
              </SectionCard>

              <SectionCard title="تعليمات المعلم" icon={<EditNoteRounded />}>
                <FieldLabel studentVisible>تعليمات المعلم</FieldLabel>
                <TextField
                  fullWidth
                  multiline
                  minRows={4}
                  disabled={!editable}
                  value={form.teacherInstructions}
                  onChange={(event) => updateForm({ teacherInstructions: event.target.value })}
                />
              </SectionCard>

              <SectionCard
                title="مرفقات (اختياري)"
                subtitle="ورقة عمل أو عرض أو ملف مساند. المرفق لا يُحتسب ضمن شروط إرسال التحضير."
                icon={<AttachFileRounded />}
              >
                {existingFiles.length > 0 && (
                  <Stack direction="row" flexWrap="wrap" gap={0.55} mb={1}>
                    {existingFiles.map((file, index) => (
                      <Chip
                        key={`${getAttachmentLabel(file, index)}-${index}`}
                        size="small"
                        icon={<AttachFileRounded />}
                        label={getAttachmentLabel(file, index)}
                        sx={{ maxWidth: 280, fontWeight: 800 }}
                      />
                    ))}
                  </Stack>
                )}

                {editable ? (
                  <Button component="label" variant="outlined" startIcon={<CloudUploadRounded />} sx={{ fontWeight: 900, textTransform: "none" }}>
                    {attachment ? attachment.name : "اختيار مرفق"}
                    <input hidden type="file" onChange={handleAttachment} />
                  </Button>
                ) : (
                  <Typography sx={{ color: "var(--color-muted)", fontSize: 11 }}>
                    {existingFiles.length
                      ? "هذه المرفقات مواد مساندة ولا تدخل ضمن شروط الإرسال."
                      : "لا توجد مرفقات مساندة لهذا التحضير."}
                  </Typography>
                )}
              </SectionCard>
            </>
          )}

          {validationErrors.length > 0 && (
            <Alert severity="error" sx={{ borderRadius: "14px" }}>
              <Typography sx={{ fontWeight: 900, mb: 0.5 }}>لا يمكن الإرسال:</Typography>
              <Stack spacing={0.35}>
                {validationErrors.map((error) => (
                  <Button
                    key={error.target}
                    type="button"
                    onClick={() => jumpToError(error)}
                    sx={{ justifyContent: "flex-start", color: "inherit", fontWeight: 800, textTransform: "none", p: 0 }}
                  >
                    • {error.message} ← اذهب
                  </Button>
                ))}
              </Stack>
            </Alert>
          )}

          <Paper
            elevation={0}
            sx={{
              position: "sticky",
              bottom: 8,
              zIndex: 18,
              p: 1.05,
              border: "1px solid rgba(36,74,112,.11)",
              borderRadius: "17px",
              bgcolor: "rgba(255,253,250,.96)",
              backdropFilter: "blur(14px)",
              boxShadow: "0 12px 34px rgba(18,47,77,.12)",
            }}
          >
            <Stack direction={{ xs: "column", sm: "row" }} justifyContent="space-between" gap={0.8}>
              <Stack direction={{ xs: "column", sm: "row" }} gap={0.7}>
                {editable && (
                  <Button
                    variant="outlined"
                    startIcon={saving ? <CircularProgress size={16} /> : <SaveRounded />}
                    disabled={saving || submitting || !form.lecture}
                    onClick={() => saveDraft()}
                    sx={{ fontWeight: 900, textTransform: "none" }}
                  >
                    حفظ كمسودة
                  </Button>
                )}
                {editable && step === 2 && (
                  <Button
                    variant="contained"
                    startIcon={submitting ? <CircularProgress size={16} color="inherit" /> : <SendRounded />}
                    disabled={saving || submitting || resourceSaving || !form.lecture}
                    onClick={handleSubmitForReview}
                    sx={{ fontWeight: 900, textTransform: "none", bgcolor: "var(--color-navy)" }}
                  >
                    إرسال للمراجعة
                  </Button>
                )}
              </Stack>
              <Stack direction={{ xs: "column", sm: "row" }} gap={0.7}>
                {step === 2 && (
                  <Button variant="text" onClick={() => changeStep(1)} sx={{ fontWeight: 900, textTransform: "none" }}>
                    السابق
                  </Button>
                )}
                {step === 1 && editable && (
                  <Button variant="contained" onClick={() => changeStep(2)} sx={{ fontWeight: 900, textTransform: "none", bgcolor: "var(--color-gold-dark)" }}>
                    متابعة
                  </Button>
                )}
                <Button variant="text" startIcon={<CloseRounded />} onClick={goBack} sx={{ fontWeight: 900, textTransform: "none", color: "var(--color-muted)" }}>
                  {readOnly ? "عودة" : "إغلاق"}
                </Button>
              </Stack>
            </Stack>
          </Paper>
        </Stack>

        <Dialog
          open={reviewDialog}
          onClose={() => !reviewing && setReviewDialog(false)}
          fullWidth
          maxWidth="sm"
        >
          <DialogTitle sx={{ fontWeight: 900 }}>طلب تعديل التحضير</DialogTitle>
          <DialogContent dividers>
            <TextField
              autoFocus
              fullWidth
              multiline
              minRows={4}
              label="ملاحظة للمعلم"
              placeholder="مثال: يرجى توضيح الأهداف وإضافة نشاط مناسب للدرس"
              value={reviewDraft}
              onChange={(event) => setReviewDraft(event.target.value)}
              inputProps={{ maxLength: 1000 }}
            />
          </DialogContent>
          <DialogActions>
            <Button
              onClick={() => setReviewDialog(false)}
              disabled={reviewing}
              sx={{ fontWeight: 800 }}
            >
              إلغاء
            </Button>
            <Button
              variant="contained"
              onClick={handleRequestRevision}
              disabled={reviewing}
              sx={{ fontWeight: 900, bgcolor: "var(--color-gold-dark)" }}
            >
              {reviewing ? "جاري الحفظ..." : "إرسال طلب التعديل"}
            </Button>
          </DialogActions>
        </Dialog>

        <Dialog open={libraryDialog} onClose={() => !librarySaving && setLibraryDialog(false)} fullWidth maxWidth="sm">
          <DialogTitle sx={{ fontWeight: 900 }}>أضف رابط أو ملف إلى مكتبة المدرسة</DialogTitle>
          <DialogContent dividers>
            <Stack spacing={1.1}>
              <TextField fullWidth size="small" label="العنوان" value={libraryDraft.title} onChange={(event) => setLibraryDraft((current) => ({ ...current, title: event.target.value }))} />
              <TextField fullWidth size="small" label="الرابط" value={libraryDraft.link} disabled={Boolean(libraryDraft.file)} onChange={(event) => setLibraryDraft((current) => ({ ...current, link: event.target.value }))} placeholder="https://..." />
              <Divider>أو</Divider>
              <Button component="label" variant="outlined" startIcon={<CloudUploadRounded />} sx={{ fontWeight: 900, textTransform: "none" }}>
                {libraryDraft.file ? libraryDraft.file.name : "اختيار ملف"}
                <input hidden type="file" onChange={(event) => setLibraryDraft((current) => ({ ...current, file: event.target.files?.[0] || null, link: "" }))} />
              </Button>
            </Stack>
          </DialogContent>
          <DialogActions>
            <Button disabled={librarySaving} onClick={() => setLibraryDialog(false)}>إلغاء</Button>
            <Button variant="contained" disabled={librarySaving} onClick={saveLibraryItem} startIcon={librarySaving ? <CircularProgress size={15} color="inherit" /> : <SaveRounded />}>
              حفظ وإضافة للتحضير
            </Button>
          </DialogActions>
        </Dialog>

        <Dialog
          open={Boolean(assignmentDialog)}
          onClose={() => {
            if (resourceSaving) return;
            setAssignmentDialog(null);
            setAssignmentEditIndex(null);
          }}
          fullWidth
          maxWidth="sm"
        >
          <DialogTitle sx={{ fontWeight: 900 }}>
            {Number.isInteger(assignmentEditIndex) ? "تعديل" : "إضافة"}{" "}
            {ASSIGNMENT_GROUPS.find((item) => item.key === assignmentDialog)?.singular || "تكليف"}
          </DialogTitle>
          <DialogContent dividers>
            {assignmentDialog === "exams" && (
              <Box mb={1.5}>
                <Typography sx={{ color: "var(--color-navy-deep)", fontWeight: 900, fontSize: 12, mb: 0.7 }}>
                  اختبارات موجودة بالفعل
                </Typography>
                {examLoading ? (
                  <CircularProgress size={22} />
                ) : examOptions.length ? (
                  <Stack spacing={0.5} sx={{ maxHeight: 220, overflowY: "auto" }}>
                    {examOptions.map((exam) => (
                      <Paper key={normalizeId(exam)} variant="outlined" sx={{ p: 0.8, borderRadius: "11px" }}>
                        <Stack direction="row" alignItems="center" justifyContent="space-between" gap={1}>
                          <Box sx={{ minWidth: 0 }}>
                            <Typography noWrap sx={{ fontSize: 11.5, fontWeight: 900 }}>{getName(exam, exam?.examTitle || "اختبار")}</Typography>
                            <Typography sx={{ fontSize: 9.5, color: "var(--color-muted)" }}>{exam?.examType || "اختبار"}</Typography>
                          </Box>
                          <Button size="small" disabled={resourceSaving} onClick={() => addExistingExam(exam)}>استخدام</Button>
                        </Stack>
                      </Paper>
                    ))}
                  </Stack>
                ) : (
                  <Typography sx={{ color: "var(--color-muted)", fontSize: 10.5 }}>لا توجد اختبارات سابقة لهذه المادة.</Typography>
                )}
                <Button
                  size="small"
                  startIcon={<AddRounded />}
                  onClick={() => navigateAway(role === "TEACHER" ? "/teacher/exams/add" : "/school/exams/add")}
                  sx={{ mt: 0.7, fontWeight: 900, textTransform: "none" }}
                >
                  إنشاء اختبار جديد
                </Button>
                <Divider sx={{ my: 1.2 }}>أو أضف وصفًا سريعًا</Divider>
              </Box>
            )}
            {assignmentDialog === "activities" && (
              <Box mb={1.5}>
                <Typography sx={{ color: "var(--color-navy-deep)", fontWeight: 900, fontSize: 12, mb: 0.7 }}>
                  مشروعات موجودة بالفعل
                </Typography>
                {projectLoading ? (
                  <CircularProgress size={22} />
                ) : projectOptions.length ? (
                  <Stack spacing={0.5} sx={{ maxHeight: 220, overflowY: "auto" }}>
                    {projectOptions.map((project) => (
                      <Paper key={normalizeId(project)} variant="outlined" sx={{ p: 0.8, borderRadius: "11px" }}>
                        <Stack direction="row" alignItems="center" justifyContent="space-between" gap={1}>
                          <Box sx={{ minWidth: 0 }}>
                            <Typography noWrap sx={{ fontSize: 11.5, fontWeight: 900 }}>
                              {getName(project, "نشاط / مشروع")}
                            </Typography>
                            <Typography sx={{ fontSize: 9.5, color: "var(--color-muted)" }}>
                              نشاط موجود لنفس الحصة والمادة
                            </Typography>
                          </Box>
                          <Button
                            size="small"
                            disabled={resourceSaving}
                            onClick={() => addExistingProject(project)}
                          >
                            استخدام
                          </Button>
                        </Stack>
                      </Paper>
                    ))}
                  </Stack>
                ) : (
                  <Typography sx={{ color: "var(--color-muted)", fontSize: 10.5 }}>
                    لا توجد مشروعات مناسبة لهذه الحصة.
                  </Typography>
                )}
                <Button
                  size="small"
                  startIcon={<AddRounded />}
                  onClick={() => navigateAway(role === "TEACHER" ? "/teacher/projects" : "/school/projects/add")}
                  sx={{ mt: 0.7, fontWeight: 900, textTransform: "none" }}
                >
                  إنشاء مشروع جديد
                </Button>
                <Divider sx={{ my: 1.2 }}>أو أضف نشاطًا سريعًا</Divider>
              </Box>
            )}
            <Stack spacing={1}>
              <TextField fullWidth size="small" label="العنوان" value={assignmentDraft.title} onChange={(event) => setAssignmentDraft((current) => ({ ...current, title: event.target.value }))} />
              <TextField
                fullWidth
                size="small"
                multiline
                minRows={2}
                label="الوصف (اختياري)"
                value={assignmentDraft.description}
                onChange={(event) => setAssignmentDraft((current) => ({ ...current, description: event.target.value }))}
              />
              <Grid container spacing={1}>
                <Grid item xs={12} sm={6}>
                  <TextField fullWidth size="small" type="date" label="البداية" InputLabelProps={{ shrink: true }} value={assignmentDraft.startDate} onChange={(event) => setAssignmentDraft((current) => ({ ...current, startDate: event.target.value }))} />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField fullWidth size="small" type="date" label="النهاية" InputLabelProps={{ shrink: true }} value={assignmentDraft.endDate} onChange={(event) => setAssignmentDraft((current) => ({ ...current, endDate: event.target.value }))} />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    size="small"
                    type="number"
                    label="الدرجة (اختياري)"
                    inputProps={{ min: 0 }}
                    value={assignmentDraft.totalGrade}
                    onChange={(event) => setAssignmentDraft((current) => ({ ...current, totalGrade: event.target.value }))}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    size="small"
                    label="رابط (اختياري)"
                    placeholder="https://..."
                    value={assignmentDraft.link}
                    onChange={(event) => setAssignmentDraft((current) => ({ ...current, link: event.target.value }))}
                  />
                </Grid>
              </Grid>
            </Stack>
          </DialogContent>
          <DialogActions>
            <Button
              disabled={resourceSaving}
              onClick={() => {
                setAssignmentDialog(null);
                setAssignmentEditIndex(null);
              }}
            >
              إلغاء
            </Button>
            <Button
              variant="contained"
              disabled={resourceSaving}
              onClick={addCustomAssignment}
              startIcon={resourceSaving ? <CircularProgress size={15} color="inherit" /> : <AddRounded />}
            >
              {Number.isInteger(assignmentEditIndex) ? "حفظ" : "إضافة"}
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    </PreparationPageWrapper>
  );
};

export default StructuredPreparationForm;
